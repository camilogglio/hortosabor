# hortosabor
App de hortosabor

# build command
ionic cordova build android --prod --aot --minifyjs --minifycss --optimizejs