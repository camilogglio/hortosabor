(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["products-products-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/products/products.page.html":
/*!***********************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/products/products.page.html ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header class=\"header-top\">\r\n  <ion-toolbar>\r\n      <ion-buttons slot=\"start\">\r\n        <ion-menu-button></ion-menu-button>\r\n      </ion-buttons>\r\n    <ion-title text-left>Products</ion-title>\r\n    <ion-buttons slot=\"end\">\r\n      <!-- <ion-icon name=\"search\"></ion-icon>\r\n      <ion-icon name=\"md-more\"></ion-icon> -->\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <div class=\"products\">\r\n     <div class=\"search\">\r\n      <ion-searchbar [(ngModel)]=\"product_search\" placeholder=\"Search\" lines=\"none\" (keyup)=\"searchProduct(product_search)\"></ion-searchbar>\r\n     </div>\r\n  </div>\r\n  <div *ngIf=\"searchResult.length>0\">\r\n    <ion-item *ngFor=\"let item of searchResult\" (click)=\"chooseItem(item)\">\r\n      {{ item.title}}\r\n   </ion-item>\r\n  </div>\r\n  <div class=\"product-slider\">\r\n    \r\n    <h2>{{selectedProduct.title}} <b>X {{selectedProduct.units}}</b></h2>\r\n        <p>{{selectedProduct.description}}</p> \r\n        <div style=\"position: absolute;top: 50%;left: 16px;font-size: 25px;z-index: 2;\" class=\"slider-arrow\" (click)=\"slidePrev($event)\">\r\n          <ion-icon name=\"ios-arrow-back\"></ion-icon>\r\n        </div>\r\n        <div style=\"position: absolute;top: 50%;right: 16px;font-size: 25px;z-index: 2;\" class=\"slider-arrow\" (click)=\"slideNext($event)\">\r\n          <ion-icon name=\"ios-arrow-forward\"></ion-icon>\r\n        </div>\r\n        <ion-spinner name=\"lines\"  *ngIf=\"spinnerStatus ==false\" text-center style=\"margin: 0 auto;\r\n        width: 100%;\r\n        padding-top: 58px;\r\n        margin-top: 50px;\"></ion-spinner>\r\n      <ion-slides #productSlide [options]=\"slideOptsOne\" (ionSlideDidChange)=\"getIndex()\">\r\n      <ion-slide *ngFor=\"let proData of products let i =index\"  id=\"{{i}}\">        \r\n        <img  src=\"{{proData.images[0]}}\"/>\r\n      </ion-slide>\r\n<!-- \r\n      <ion-slide> \r\n        <img src=\"../../assets/images/slide-2.png\"/>      \r\n      </ion-slide>\r\n\r\n      <ion-slide>\r\n        <img src=\"../../assets/images/slide-1.png\"/>\r\n        \r\n      </ion-slide>\r\n      <ion-slide>      \r\n        <img src=\"../../assets/images/slide-2.png\"/>       \r\n      </ion-slide> -->\r\n    </ion-slides>\r\n    \r\n    <div class=\"price_product\">\r\n    <ion-row>\r\n      <ion-col size=\"6\">\r\n         <div class=\"price text-left\">\r\n          <h4>{{selectedProduct.price | currency :'USD'}}</h4>\r\n          <!-- <p>Lorem Ipsum</p> -->\r\n         </div>\r\n      </ion-col>\r\n      <ion-col size=\"6\">\r\n        <div class=\"btn-cart\">\r\n        <ion-row>\r\n          <ion-col size=\"8\" text-left class=\"cart-input\">\r\n            <!-- <ion-input type=\"checkbox\"></ion-input> -->\r\n            {{quantity}}\r\n            <div class=\"up-down-arrow\">\r\n            <ion-icon name=\"arrow-dropup\" ios=\"ios-arrow-dropup\" md=\"md-arrow-dropup\" color=\"dark\" (click)=\"addQuantity()\"></ion-icon>\r\n            <ion-icon name=\"arrow-dropdown\" ios=\"ios-arrow-dropdown\" md=\"md-arrow-dropdown\" color=\"dark\" (click)=\"removeQuantity()\"></ion-icon>\r\n          </div>\r\n            <!-- <img src=\"../../assets/images/arrow.png\" class=\"arrow\"/> -->\r\n          </ion-col>\r\n          <ion-col size=\"4\" text-right class=\"ion-cart\" (click)=\"addCart()\">\r\n            <ion-icon name=\"cart\"></ion-icon>\r\n          </ion-col>\r\n        </ion-row>\r\n      </div>\r\n      </ion-col>\r\n    </ion-row>\r\n    <div class=\"price-button\">\r\n      <ion-row>\r\n        <ion-col size=\"6\" text-left>\r\n          <h3>Total </h3>\r\n        </ion-col>\r\n        <ion-col size=\"6\" text-right>\r\n          <h3><b>{{total | currency :'USD'}}</b></h3>\r\n        </ion-col>\r\n      </ion-row>\r\n       \r\n    </div>\r\n\r\n    <ion-button lines=\"none\" class=\"cart-buttons\" expand=\"block\" fill=\"outline\" (click)=\"goTo('/cartlist')\">SEE CART LIST</ion-button>\r\n  </div>\r\n  </div>\r\n</ion-content>\r\n"

/***/ }),

/***/ "./src/app/products/products-routing.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/products/products-routing.module.ts ***!
  \*****************************************************/
/*! exports provided: ProductsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductsPageRoutingModule", function() { return ProductsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _products_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./products.page */ "./src/app/products/products.page.ts");




const routes = [
    {
        path: '',
        component: _products_page__WEBPACK_IMPORTED_MODULE_3__["ProductsPage"]
    }
];
let ProductsPageRoutingModule = class ProductsPageRoutingModule {
};
ProductsPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ProductsPageRoutingModule);



/***/ }),

/***/ "./src/app/products/products.module.ts":
/*!*********************************************!*\
  !*** ./src/app/products/products.module.ts ***!
  \*********************************************/
/*! exports provided: ProductsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductsPageModule", function() { return ProductsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _products_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./products-routing.module */ "./src/app/products/products-routing.module.ts");
/* harmony import */ var _products_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./products.page */ "./src/app/products/products.page.ts");







let ProductsPageModule = class ProductsPageModule {
};
ProductsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _products_routing_module__WEBPACK_IMPORTED_MODULE_5__["ProductsPageRoutingModule"]
        ],
        declarations: [_products_page__WEBPACK_IMPORTED_MODULE_6__["ProductsPage"]]
    })
], ProductsPageModule);



/***/ }),

/***/ "./src/app/products/products.page.scss":
/*!*********************************************!*\
  !*** ./src/app/products/products.page.scss ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-toolbar {\n  --background: #00b84c;\n}\n\nion-title {\n  color: #ffda01;\n  font-size: 20px;\n  vertical-align: middle;\n}\n\nion-icon {\n  color: #fff;\n  font-size: 24px;\n}\n\n.products {\n  padding: 20px;\n}\n\nion-searchbar {\n  height: 50px !important;\n  contain: strict !important;\n  border: 1px solid #8c8a8a !important;\n  border-radius: 15px !important;\n  --background: #fff !important;\n  width: 100% !important;\n}\n\n.product-slider {\n  padding: 20px 0px;\n  background: #f4f4f4;\n}\n\n.product-slider h2 {\n  font-size: 36px;\n  color: #474747;\n  font-weight: 600;\n  margin-bottom: 0;\n  text-align: center;\n}\n\n.product-slider p {\n  font-size: 18px;\n  color: #00b84c;\n  margin: 0;\n  text-align: center;\n}\n\n.swiper-slide {\n  display: block;\n  margin: 30px 0px;\n}\n\nion-slide > img {\n  margin: 0px 0;\n  width: 300px;\n  height: 150px;\n}\n\n.price h4 {\n  font-size: 36px;\n  color: #676564;\n  font-weight: bold;\n  margin: 0;\n  text-align: left;\n}\n\n.price p {\n  font-size: 14px;\n  text-align: left;\n  margin: 0;\n}\n\n.cart-button {\n  border-radius: 50px;\n  --border-radius: 50px;\n  --border-color: #f16000;\n  --border-width: 2px;\n}\n\n.cart-button ion-icon {\n  margin-top: 0px;\n  background: #f16000;\n  padding: 10px;\n}\n\n.price-button {\n  background: #f16000;\n  border-radius: 7px;\n  margin-top: 40px;\n  margin-bottom: 40px;\n  padding: 0px 10px;\n}\n\n.price-button h3 {\n  color: #fff;\n}\n\n.cart-buttons {\n  color: #f16000;\n  --border-color: #f16000;\n  font-weight: bold;\n  font-size: 18px;\n  --border-radius: 5px;\n  margin: 40px 30px;\n  height: 48px;\n}\n\n.btn-cart {\n  border: 1px solid #f16000;\n  font-weight: bold;\n  font-size: 24px;\n  text-align: right;\n  border-radius: 50px;\n  line-height: 46px;\n  text-align: center;\n  padding-left: 18px;\n}\n\n.ion-cart {\n  background-color: #f16000;\n  border-radius: 0px 50px 50px 0px;\n}\n\n.ion-cart ion-icon {\n  color: #fff;\n  margin-top: 0;\n  text-align: center;\n  padding-right: 7px;\n}\n\nimg.arrow {\n  width: 15px;\n  float: right;\n  right: 6px;\n  top: 15%;\n  position: absolute;\n}\n\n.price_product {\n  padding: 20px;\n}\n\n.searchbar-input {\n  box-shadow: none !important;\n}\n\n.up-down-arrow {\n  display: inline-grid;\n  float: right;\n}\n\n@media (max-width: 411px) {\n  .slider-arrow {\n    top: 50% !important;\n  }\n\n  img.arrow {\n    top: 17%;\n  }\n}\n\n@media (max-width: 375px) {\n  .slider-arrow {\n    top: 44% !important;\n  }\n}\n\n@media (max-width: 360px) {\n  .slider-arrow {\n    top: 54% !important;\n  }\n\n  .price h4 {\n    font-size: 28px;\n  }\n\n  .product-slider h2 {\n    font-size: 30px;\n  }\n\n  .product-slider p {\n    font-size: 16px;\n  }\n}\n\n@media (max-width: 320px) {\n  .product-slider h2 {\n    font-size: 24px;\n  }\n\n  .product-slider .slider-arrow {\n    top: 60% !important;\n  }\n\n  .price h4 {\n    font-size: 24px;\n  }\n\n  .product-slider p {\n    font-size: 14px;\n  }\n\n  .price-button h3 {\n    color: #fff;\n    font-size: 18px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcHJvZHVjdHMvRDpcXGJhYml0YVxcaG9ydG9zYWJvci9zcmNcXGFwcFxccHJvZHVjdHNcXHByb2R1Y3RzLnBhZ2Uuc2NzcyIsInNyYy9hcHAvcHJvZHVjdHMvcHJvZHVjdHMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0kscUJBQUE7QUNDSjs7QURDQTtFQUNJLGNBQUE7RUFDQSxlQUFBO0VBQ0Esc0JBQUE7QUNFSjs7QURDQTtFQUNJLFdBQUE7RUFDQSxlQUFBO0FDRUo7O0FEQUE7RUFDSSxhQUFBO0FDR0o7O0FEREE7RUFDSSx1QkFBQTtFQUNBLDBCQUFBO0VBQ0Esb0NBQUE7RUFDQSw4QkFBQTtFQUNBLDZCQUFBO0VBQ0Esc0JBQUE7QUNJSjs7QURGQTtFQUNJLGlCQUFBO0VBQ0EsbUJBQUE7QUNLSjs7QURIQTtFQUNJLGVBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0FDTUo7O0FESkU7RUFDRSxlQUFBO0VBQ0EsY0FBQTtFQUNBLFNBQUE7RUFDQSxrQkFBQTtBQ09KOztBRExBO0VBQ0ksY0FBQTtFQUNBLGdCQUFBO0FDUUo7O0FETEU7RUFHRSxhQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7QUNNSjs7QURKRTtFQUNJLGVBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7RUFDQSxTQUFBO0VBQ0EsZ0JBQUE7QUNPTjs7QURMRTtFQUNJLGVBQUE7RUFDQSxnQkFBQTtFQUNBLFNBQUE7QUNRTjs7QURORTtFQUVFLG1CQUFBO0VBQ0EscUJBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FDUUo7O0FETkE7RUFDSSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSxhQUFBO0FDU0o7O0FEUEE7RUFDSSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0FDVUo7O0FEUkE7RUFDSSxXQUFBO0FDV0o7O0FEVEE7RUFDSSxjQUFBO0VBQ0EsdUJBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7RUFDQSxvQkFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtBQ1lKOztBRFZBO0VBQ0kseUJBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FDYUo7O0FEWEE7RUFDSSx5QkFBQTtFQUNBLGdDQUFBO0FDY0o7O0FEWkE7RUFDSSxXQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7QUNlSjs7QURiQTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0EsVUFBQTtFQUNBLFFBQUE7RUFDQSxrQkFBQTtBQ2dCSjs7QURkQTtFQUNJLGFBQUE7QUNpQko7O0FEZkE7RUFDSSwyQkFBQTtBQ2tCSjs7QURmQTtFQUNJLG9CQUFBO0VBQ0EsWUFBQTtBQ2tCSjs7QURoQkE7RUFDQTtJQUNJLG1CQUFBO0VDbUJGOztFRGpCRjtJQUNJLFFBQUE7RUNvQkY7QUFDRjs7QURsQkE7RUFDSTtJQUNJLG1CQUFBO0VDb0JOO0FBQ0Y7O0FEbEJBO0VBQ0k7SUFDSSxtQkFBQTtFQ29CTjs7RURsQkU7SUFDQSxlQUFBO0VDcUJGOztFRG5CRTtJQUNJLGVBQUE7RUNzQk47O0VEcEJFO0lBQ0ksZUFBQTtFQ3VCTjtBQUNGOztBRHJCQTtFQUNJO0lBQ0ksZUFBQTtFQ3VCTjs7RURyQkU7SUFDSSxtQkFBQTtFQ3dCTjs7RUR0QkU7SUFDSSxlQUFBO0VDeUJOOztFRHZCRTtJQUNJLGVBQUE7RUMwQk47O0VEeEJFO0lBQ0ksV0FBQTtJQUNBLGVBQUE7RUMyQk47QUFDRiIsImZpbGUiOiJzcmMvYXBwL3Byb2R1Y3RzL3Byb2R1Y3RzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi10b29sYmFyIHtcclxuICAgIC0tYmFja2dyb3VuZDogIzAwYjg0YztcclxufVxyXG5pb24tdGl0bGV7XHJcbiAgICBjb2xvcjojZmZkYTAxO1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcclxufVxyXG5cclxuaW9uLWljb24ge1xyXG4gICAgY29sb3I6ICNmZmY7XHJcbiAgICBmb250LXNpemU6IDI0cHg7XHJcbn1cclxuLnByb2R1Y3Rze1xyXG4gICAgcGFkZGluZzoyMHB4O1xyXG59XHJcbmlvbi1zZWFyY2hiYXJ7XHJcbiAgICBoZWlnaHQ6IDUwcHggIWltcG9ydGFudDtcclxuICAgIGNvbnRhaW46IHN0cmljdCAhaW1wb3J0YW50O1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgIzhjOGE4YSAhaW1wb3J0YW50O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTVweCAhaW1wb3J0YW50O1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjZmZmICFpbXBvcnRhbnQ7XHJcbiAgICB3aWR0aDogMTAwJSAhaW1wb3J0YW50O1xyXG59XHJcbi5wcm9kdWN0LXNsaWRlcntcclxuICAgIHBhZGRpbmc6MjBweCAwcHg7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZjRmNGY0O1xyXG59XHJcbi5wcm9kdWN0LXNsaWRlciBoMiB7XHJcbiAgICBmb250LXNpemU6IDM2cHg7XHJcbiAgICBjb2xvcjogIzQ3NDc0NztcclxuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAwO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIH1cclxuICAucHJvZHVjdC1zbGlkZXIgIHB7XHJcbiAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICBjb2xvcjojMDBiODRjO1xyXG4gICAgbWFyZ2luOiAwO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIH1cclxuLnN3aXBlci1zbGlkZSB7XHJcbiAgICBkaXNwbGF5OiBibG9jazsgXHJcbiAgICBtYXJnaW46IDMwcHggMHB4OyAgICAgICAgIFxyXG4gICAgfVxyXG4gICBcclxuICBpb24tc2xpZGUgPiBpbWcge1xyXG4gICAgLy8gbWF4LWhlaWdodDogMTAwJTtcclxuICAgIC8vIG1heC13aWR0aDogMTAwJTtcclxuICAgIG1hcmdpbjogMHB4IDA7XHJcbiAgICB3aWR0aDogMzAwcHg7XHJcbiAgICBoZWlnaHQ6IDE1MHB4O1xyXG4gIH1cclxuICAucHJpY2UgaDR7XHJcbiAgICAgIGZvbnQtc2l6ZTozNnB4O1xyXG4gICAgICBjb2xvcjogIzY3NjU2NDtcclxuICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICAgIG1hcmdpbjogMDtcclxuICAgICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICB9XHJcbiAgLnByaWNlIHB7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgICAgbWFyZ2luOiAwO1xyXG4gIH1cclxuICAuY2FydC1idXR0b24ge1xyXG4gICAgLy8gLS1iYWNrZ3JvdW5kOiAjZjE2MDAwO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNTBweDtcclxuICAgIC0tYm9yZGVyLXJhZGl1czogNTBweDtcclxuICAgIC0tYm9yZGVyLWNvbG9yOiAjZjE2MDAwO1xyXG4gICAgLS1ib3JkZXItd2lkdGg6IDJweDtcclxufVxyXG4uY2FydC1idXR0b24gaW9uLWljb257XHJcbiAgICBtYXJnaW4tdG9wOjBweDtcclxuICAgIGJhY2tncm91bmQ6ICNmMTYwMDA7XHJcbiAgICBwYWRkaW5nOiAxMHB4O1xyXG59XHJcbi5wcmljZS1idXR0b257XHJcbiAgICBiYWNrZ3JvdW5kOiAjZjE2MDAwO1xyXG4gICAgYm9yZGVyLXJhZGl1czogN3B4O1xyXG4gICAgbWFyZ2luLXRvcDogNDBweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDQwcHg7IFxyXG4gICAgcGFkZGluZzogMHB4IDEwcHg7XHJcbn1cclxuLnByaWNlLWJ1dHRvbiBoM3tcclxuICAgIGNvbG9yOiAjZmZmO1xyXG59XHJcbi5jYXJ0LWJ1dHRvbnN7XHJcbiAgICBjb2xvcjogI2YxNjAwMDtcclxuICAgIC0tYm9yZGVyLWNvbG9yOiAjZjE2MDAwO1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICAtLWJvcmRlci1yYWRpdXM6IDVweDtcclxuICAgIG1hcmdpbjogNDBweCAzMHB4O1xyXG4gICAgaGVpZ2h0OjQ4cHhcclxufVxyXG4uYnRuLWNhcnQge1xyXG4gICAgYm9yZGVyOjFweCBzb2xpZCAjZjE2MDAwO1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICBmb250LXNpemU6IDI0cHg7XHJcbiAgICB0ZXh0LWFsaWduOiByaWdodDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDUwcHg7XHJcbiAgICBsaW5lLWhlaWdodDogNDZweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIHBhZGRpbmctbGVmdDogMThweDtcclxufVxyXG4uaW9uLWNhcnR7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiNmMTYwMDA7XHJcbiAgICBib3JkZXItcmFkaXVzOjBweCA1MHB4IDUwcHggMHB4O1xyXG59XHJcbi5pb24tY2FydCBpb24taWNvbntcclxuICAgIGNvbG9yOiNmZmY7XHJcbiAgICBtYXJnaW4tdG9wOjA7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiA3cHg7XHJcbn1cclxuaW1nLmFycm93IHtcclxuICAgIHdpZHRoOiAxNXB4O1xyXG4gICAgZmxvYXQ6IHJpZ2h0O1xyXG4gICAgcmlnaHQ6IDZweDtcclxuICAgIHRvcDogMTUlO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG59XHJcbi5wcmljZV9wcm9kdWN0e1xyXG4gICAgcGFkZGluZzoyMHB4O1xyXG59XHJcbi5zZWFyY2hiYXItaW5wdXQge1xyXG4gICAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xyXG5cclxufVxyXG4udXAtZG93bi1hcnJvdyB7XHJcbiAgICBkaXNwbGF5OiBpbmxpbmUtZ3JpZDtcclxuICAgIGZsb2F0OiByaWdodDtcclxufVxyXG5AbWVkaWEgKG1heC13aWR0aDogNDExcHgpe1xyXG4uc2xpZGVyLWFycm93IHtcclxuICAgIHRvcDogNTAlICFpbXBvcnRhbnQ7XHJcbn1cclxuaW1nLmFycm93e1xyXG4gICAgdG9wOiAxNyUgO1xyXG59XHJcbn1cclxuQG1lZGlhIChtYXgtd2lkdGg6Mzc1cHgpe1xyXG4gICAgLnNsaWRlci1hcnJvd3tcclxuICAgICAgICB0b3A6NDQlICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbn1cclxuQG1lZGlhIChtYXgtd2lkdGg6IDM2MHB4KXtcclxuICAgIC5zbGlkZXItYXJyb3cge1xyXG4gICAgICAgIHRvcDogNTQlICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAucHJpY2UgaDR7XHJcbiAgICBmb250LXNpemU6IDI4cHg7XHJcbiAgICB9XHJcbiAgICAucHJvZHVjdC1zbGlkZXIgaDIge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMzBweDtcclxuICAgIH1cclxuICAgIC5wcm9kdWN0LXNsaWRlciBwe1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgIH1cclxuICAgIH1cclxuQG1lZGlhIChtYXgtd2lkdGg6MzIwcHgpe1xyXG4gICAgLnByb2R1Y3Qtc2xpZGVyIGgyIHtcclxuICAgICAgICBmb250LXNpemU6IDI0cHg7XHJcbiAgICB9XHJcbiAgICAucHJvZHVjdC1zbGlkZXIgLnNsaWRlci1hcnJvd3tcclxuICAgICAgICB0b3A6NjAlICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAucHJpY2UgaDQge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMjRweDtcclxuICAgIH1cclxuICAgIC5wcm9kdWN0LXNsaWRlciBwe1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIH1cclxuICAgIC5wcmljZS1idXR0b24gaDMge1xyXG4gICAgICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMThweDtcclxuICAgIH1cclxuICAgIH0iLCJpb24tdG9vbGJhciB7XG4gIC0tYmFja2dyb3VuZDogIzAwYjg0Yztcbn1cblxuaW9uLXRpdGxlIHtcbiAgY29sb3I6ICNmZmRhMDE7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbn1cblxuaW9uLWljb24ge1xuICBjb2xvcjogI2ZmZjtcbiAgZm9udC1zaXplOiAyNHB4O1xufVxuXG4ucHJvZHVjdHMge1xuICBwYWRkaW5nOiAyMHB4O1xufVxuXG5pb24tc2VhcmNoYmFyIHtcbiAgaGVpZ2h0OiA1MHB4ICFpbXBvcnRhbnQ7XG4gIGNvbnRhaW46IHN0cmljdCAhaW1wb3J0YW50O1xuICBib3JkZXI6IDFweCBzb2xpZCAjOGM4YThhICFpbXBvcnRhbnQ7XG4gIGJvcmRlci1yYWRpdXM6IDE1cHggIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kOiAjZmZmICFpbXBvcnRhbnQ7XG4gIHdpZHRoOiAxMDAlICFpbXBvcnRhbnQ7XG59XG5cbi5wcm9kdWN0LXNsaWRlciB7XG4gIHBhZGRpbmc6IDIwcHggMHB4O1xuICBiYWNrZ3JvdW5kOiAjZjRmNGY0O1xufVxuXG4ucHJvZHVjdC1zbGlkZXIgaDIge1xuICBmb250LXNpemU6IDM2cHg7XG4gIGNvbG9yOiAjNDc0NzQ3O1xuICBmb250LXdlaWdodDogNjAwO1xuICBtYXJnaW4tYm90dG9tOiAwO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbi5wcm9kdWN0LXNsaWRlciBwIHtcbiAgZm9udC1zaXplOiAxOHB4O1xuICBjb2xvcjogIzAwYjg0YztcbiAgbWFyZ2luOiAwO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbi5zd2lwZXItc2xpZGUge1xuICBkaXNwbGF5OiBibG9jaztcbiAgbWFyZ2luOiAzMHB4IDBweDtcbn1cblxuaW9uLXNsaWRlID4gaW1nIHtcbiAgbWFyZ2luOiAwcHggMDtcbiAgd2lkdGg6IDMwMHB4O1xuICBoZWlnaHQ6IDE1MHB4O1xufVxuXG4ucHJpY2UgaDQge1xuICBmb250LXNpemU6IDM2cHg7XG4gIGNvbG9yOiAjNjc2NTY0O1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgbWFyZ2luOiAwO1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xufVxuXG4ucHJpY2UgcCB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgbWFyZ2luOiAwO1xufVxuXG4uY2FydC1idXR0b24ge1xuICBib3JkZXItcmFkaXVzOiA1MHB4O1xuICAtLWJvcmRlci1yYWRpdXM6IDUwcHg7XG4gIC0tYm9yZGVyLWNvbG9yOiAjZjE2MDAwO1xuICAtLWJvcmRlci13aWR0aDogMnB4O1xufVxuXG4uY2FydC1idXR0b24gaW9uLWljb24ge1xuICBtYXJnaW4tdG9wOiAwcHg7XG4gIGJhY2tncm91bmQ6ICNmMTYwMDA7XG4gIHBhZGRpbmc6IDEwcHg7XG59XG5cbi5wcmljZS1idXR0b24ge1xuICBiYWNrZ3JvdW5kOiAjZjE2MDAwO1xuICBib3JkZXItcmFkaXVzOiA3cHg7XG4gIG1hcmdpbi10b3A6IDQwcHg7XG4gIG1hcmdpbi1ib3R0b206IDQwcHg7XG4gIHBhZGRpbmc6IDBweCAxMHB4O1xufVxuXG4ucHJpY2UtYnV0dG9uIGgzIHtcbiAgY29sb3I6ICNmZmY7XG59XG5cbi5jYXJ0LWJ1dHRvbnMge1xuICBjb2xvcjogI2YxNjAwMDtcbiAgLS1ib3JkZXItY29sb3I6ICNmMTYwMDA7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBmb250LXNpemU6IDE4cHg7XG4gIC0tYm9yZGVyLXJhZGl1czogNXB4O1xuICBtYXJnaW46IDQwcHggMzBweDtcbiAgaGVpZ2h0OiA0OHB4O1xufVxuXG4uYnRuLWNhcnQge1xuICBib3JkZXI6IDFweCBzb2xpZCAjZjE2MDAwO1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgZm9udC1zaXplOiAyNHB4O1xuICB0ZXh0LWFsaWduOiByaWdodDtcbiAgYm9yZGVyLXJhZGl1czogNTBweDtcbiAgbGluZS1oZWlnaHQ6IDQ2cHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgcGFkZGluZy1sZWZ0OiAxOHB4O1xufVxuXG4uaW9uLWNhcnQge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjE2MDAwO1xuICBib3JkZXItcmFkaXVzOiAwcHggNTBweCA1MHB4IDBweDtcbn1cblxuLmlvbi1jYXJ0IGlvbi1pY29uIHtcbiAgY29sb3I6ICNmZmY7XG4gIG1hcmdpbi10b3A6IDA7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgcGFkZGluZy1yaWdodDogN3B4O1xufVxuXG5pbWcuYXJyb3cge1xuICB3aWR0aDogMTVweDtcbiAgZmxvYXQ6IHJpZ2h0O1xuICByaWdodDogNnB4O1xuICB0b3A6IDE1JTtcbiAgcG9zaXRpb246IGFic29sdXRlO1xufVxuXG4ucHJpY2VfcHJvZHVjdCB7XG4gIHBhZGRpbmc6IDIwcHg7XG59XG5cbi5zZWFyY2hiYXItaW5wdXQge1xuICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XG59XG5cbi51cC1kb3duLWFycm93IHtcbiAgZGlzcGxheTogaW5saW5lLWdyaWQ7XG4gIGZsb2F0OiByaWdodDtcbn1cblxuQG1lZGlhIChtYXgtd2lkdGg6IDQxMXB4KSB7XG4gIC5zbGlkZXItYXJyb3cge1xuICAgIHRvcDogNTAlICFpbXBvcnRhbnQ7XG4gIH1cblxuICBpbWcuYXJyb3cge1xuICAgIHRvcDogMTclO1xuICB9XG59XG5AbWVkaWEgKG1heC13aWR0aDogMzc1cHgpIHtcbiAgLnNsaWRlci1hcnJvdyB7XG4gICAgdG9wOiA0NCUgIWltcG9ydGFudDtcbiAgfVxufVxuQG1lZGlhIChtYXgtd2lkdGg6IDM2MHB4KSB7XG4gIC5zbGlkZXItYXJyb3cge1xuICAgIHRvcDogNTQlICFpbXBvcnRhbnQ7XG4gIH1cblxuICAucHJpY2UgaDQge1xuICAgIGZvbnQtc2l6ZTogMjhweDtcbiAgfVxuXG4gIC5wcm9kdWN0LXNsaWRlciBoMiB7XG4gICAgZm9udC1zaXplOiAzMHB4O1xuICB9XG5cbiAgLnByb2R1Y3Qtc2xpZGVyIHAge1xuICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgfVxufVxuQG1lZGlhIChtYXgtd2lkdGg6IDMyMHB4KSB7XG4gIC5wcm9kdWN0LXNsaWRlciBoMiB7XG4gICAgZm9udC1zaXplOiAyNHB4O1xuICB9XG5cbiAgLnByb2R1Y3Qtc2xpZGVyIC5zbGlkZXItYXJyb3cge1xuICAgIHRvcDogNjAlICFpbXBvcnRhbnQ7XG4gIH1cblxuICAucHJpY2UgaDQge1xuICAgIGZvbnQtc2l6ZTogMjRweDtcbiAgfVxuXG4gIC5wcm9kdWN0LXNsaWRlciBwIHtcbiAgICBmb250LXNpemU6IDE0cHg7XG4gIH1cblxuICAucHJpY2UtYnV0dG9uIGgzIHtcbiAgICBjb2xvcjogI2ZmZjtcbiAgICBmb250LXNpemU6IDE4cHg7XG4gIH1cbn0iXX0= */"

/***/ }),

/***/ "./src/app/products/products.page.ts":
/*!*******************************************!*\
  !*** ./src/app/products/products.page.ts ***!
  \*******************************************/
/*! exports provided: ProductsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductsPage", function() { return ProductsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _api_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../api.service */ "./src/app/api.service.ts");
/* harmony import */ var _cart_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../cart.service */ "./src/app/cart.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");






let ProductsPage = class ProductsPage {
    constructor(navCtrl, router, route, api, cart) {
        this.navCtrl = navCtrl;
        this.router = router;
        this.route = route;
        this.api = api;
        this.cart = cart;
        this.slideOptsOne = {
            initialSlide: 0,
            // slidesPerView: 1.5,
            autoplay: false,
            pager: true
        };
        this.spinnerStatus = false;
        this.cartData = [];
        this.navData = {};
        this.quantity = 1;
        this.selectedProduct = {};
        this.products = [];
        this.searchResult = [];
        this.product_search = '';
        this.total = 0;
        this.total = this.cart.calculateTotal();
        console.log(this.cart.calculateTotal());
        this.getProducts();
        this.route.queryParams.subscribe(params => {
            if (params && params.delivery) {
                this.navData = JSON.parse(params.delivery);
                console.log('Nav Data', this.navData);
                this.total = this.cart.calculateTotal();
                this.getProducts();
            }
        });
    }
    addQuantity() {
        this.quantity = this.quantity + 1;
        this.selectedProduct.quantity = this.quantity;
    }
    removeQuantity() {
        if (this.quantity > 1) {
            this.quantity = this.quantity - 1;
            this.selectedProduct.quantity = this.quantity;
        }
    }
    ngOnInit() {
        this.total = this.cart.calculateTotal();
    }
    slidePrev(evt) {
        this.quantity = 1;
        console.log('EddVT:- ', evt, this.productSlide);
        this.productSlide.slidePrev();
        this.productSlide.getActiveIndex().then((index) => {
            console.log(index, "index");
            this.selectedProduct = this.products[index];
        });
    }
    getIndex(testSlider) {
        this.quantity = 1;
        this.productSlide.getActiveIndex().then((index) => {
            console.log(index, "index");
            this.selectedProduct = this.products[index];
            this.selectedProduct.quantity = this.quantity;
            console.log("selected", this.selectedProduct);
        });
    }
    slideNext(evt) {
        this.quantity = 1;
        console.log('EVT:- ', evt, this.productSlide);
        this.productSlide.slideNext();
        // console.log(this.productSlide.getActiveIndex());
        this.productSlide.getActiveIndex().then((index) => {
            console.log(index, "index");
            this.selectedProduct = this.products[index];
            this.selectedProduct.quantity = this.quantity;
            console.log("selected", this.selectedProduct);
        });
    }
    // this.slide.ionSlideNextStart;
    searchProduct(value) {
        console.log(value);
        const url = '/search';
        const params = {
            key: value
        };
        this.api.post(url, params).subscribe(data => {
            console.log('res:- ', data);
            if (data.search.length > 0) {
                this.searchResult = data.search;
            }
            else {
                this.searchResult = [];
            }
        }, err => {
            console.log('err:- ', err);
        });
    }
    chooseItem(productData) {
        console.log(productData, "hhh");
        console.log(this.products, "uu");
        this.products.forEach((element, key) => {
            if (productData.id == element.id) {
                console.log("match");
                this.selectedProduct = this.products[key];
                this.productSlide.slideTo(key);
                this.product_search = '';
            }
        });
        this.searchResult = [];
    }
    goTo(url) {
        this.router.navigate([url], { queryParams: { value: JSON.stringify(this.navData) } });
        // this.navCtrl.navigateForward(url);
    }
    getProducts() {
        this.spinnerStatus = false;
        // this.api.showLoader();
        const url = '/products';
        const params = {};
        this.api.get(url, params).subscribe(data => {
            console.log('products res:- ', data);
            setTimeout(() => {
                // this.api.hideLoader();
            }, 100);
            this.spinnerStatus = true;
            if (data.products) {
                this.products = data.products;
                this.selectedProduct = this.products[0];
                this.selectedProduct.quantity = this.quantity;
            }
            console.log(this.selectedProduct, "selected");
        }, err => {
            setTimeout(() => {
                // this.api.hideLoader();
            }, 100);
            console.log('products err:- ', err);
        });
    }
    addCart() {
        this.total = 0;
        this.cartData = [];
        if (JSON.parse(localStorage.getItem("cart_data")) == null || JSON.parse(localStorage.getItem("cart_data")) == undefined) {
            this.cartData = [];
        }
        else {
            this.cartData = JSON.parse(localStorage.getItem("cart_data"));
        }
        console.log(this.cartData);
        var len = this.cartData.length;
        var doPush = 0;
        for (var i = 0; i < len; i++) {
            if (this.cartData[i].id && this.cartData[i].id == this.selectedProduct.id) {
                this.cartData[i].quantity = this.cartData[i].quantity + this.selectedProduct.quantity;
                // this.cartData.splice(i, 1);
                doPush = 1;
            }
        }
        if (doPush === 0) {
            this.cartData.push(this.selectedProduct);
        }
        localStorage.setItem("cart_data", JSON.stringify(this.cartData));
        this.total = this.cart.calculateTotal();
        this.api.presentToast('Product added to cart successfully.');
    }
};
ProductsPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] },
    { type: _api_service__WEBPACK_IMPORTED_MODULE_3__["ApiService"] },
    { type: _cart_service__WEBPACK_IMPORTED_MODULE_4__["CartService"] }
];
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('productSlide', { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonSlides"])
], ProductsPage.prototype, "productSlide", void 0);
ProductsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-products',
        template: __webpack_require__(/*! raw-loader!./products.page.html */ "./node_modules/raw-loader/index.js!./src/app/products/products.page.html"),
        styles: [__webpack_require__(/*! ./products.page.scss */ "./src/app/products/products.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"],
        _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"],
        _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"],
        _api_service__WEBPACK_IMPORTED_MODULE_3__["ApiService"],
        _cart_service__WEBPACK_IMPORTED_MODULE_4__["CartService"]])
], ProductsPage);



/***/ })

}]);
//# sourceMappingURL=products-products-module-es2015.js.map