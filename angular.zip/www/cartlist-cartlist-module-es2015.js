(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["cartlist-cartlist-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/cartlist/cartlist.page.html":
/*!***********************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/cartlist/cartlist.page.html ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header class=\"header-top\">\r\n  <ion-toolbar>\r\n      <ion-buttons slot=\"start\">\r\n        <ion-menu-button></ion-menu-button>\r\n      </ion-buttons>\r\n    <ion-title text-left>Cart List</ion-title>\r\n    <ion-buttons slot=\"end\">\r\n      <!-- <ion-icon name=\"search\"></ion-icon>\r\n      <ion-icon name=\"md-more\"></ion-icon> -->\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content >\r\n  <div *ngIf=\"cartList.length>0\">\r\n    <ion-row class=\"cart-list\" *ngFor=\"let cart of cartList; let i = index\"  [ngClass]=\"{'active': cart.selectedstatus == true}\"  (click)=\"SelectedProduct(cart,i)\">\r\n      <!-- <div > -->\r\n        <ion-col size=\"1\" >\r\n          <p class=\"count\">{{cart.quantity}}</p>\r\n         </ion-col>\r\n         <ion-col size=\"5\">\r\n           <div class=\"product-img\">\r\n             <img src=\"../../assets/images/Orange.png\" *ngIf=\"cart.images.length ==0\"\r\n             />\r\n             <img src=\"{{cart.images[0]}}\" *ngIf=\"cart.images.length>0\"\r\n             />\r\n            \r\n           </div>\r\n           <h4 style=\"font-size:13px;\">{{cart.title}} X {{cart.units}}</h4>\r\n         </ion-col>\r\n         <ion-col size=\"3\">\r\n           <h5 class=\"price\">{{cart.price | currency: 'USD'}}</h5>\r\n         </ion-col>\r\n         <ion-col size=\"3\">\r\n           <h5 class=\"price\">{{cart.subtotal | currency: 'USD'}}</h5>\r\n         </ion-col>\r\n      <!-- </div>    -->\r\n    </ion-row>\r\n     <!-- <ion-row class=\"cart-list\">\r\n    <ion-col size=\"1\">\r\n     <p class=\"count\">2</p>\r\n    </ion-col>\r\n    <ion-col size=\"5\">\r\n      <div class=\"product-img\">\r\n        <img src=\"../../assets/images/Banana.png\"/>\r\n        <h4>Banana X 1Kg</h4>\r\n      </div>\r\n    </ion-col>\r\n    <ion-col size=\"3\">\r\n      <h5 class=\"price\">$55.00</h5>\r\n    </ion-col>\r\n    <ion-col size=\"3\">\r\n      <h5 class=\"price\">$55.00</h5>\r\n    </ion-col>\r\n  </ion-row> -->\r\n  <!-- <ion-row class=\"cart-list\">\r\n    <ion-col size=\"1\">\r\n     <p class=\"count\">3</p>\r\n    </ion-col>\r\n    <ion-col size=\"5\">\r\n      <div class=\"product-img\">\r\n        <img src=\"../../assets/images/Tomatos.png\"/>\r\n        <h4>Banana X 1Kg</h4>\r\n      </div>\r\n    </ion-col>\r\n    <ion-col size=\"3\">\r\n      <h5 class=\"price\">$55.00</h5>\r\n    </ion-col>\r\n    <ion-col size=\"3\">\r\n      <h5 class=\"price\">$55.00</h5>\r\n    </ion-col>\r\n  </ion-row> -->\r\n  <ion-row text-center class=\"carticons\">\r\n    <ion-col size=\"4\">\r\n      <div class=\"cart-icons\" (click)=\"add_quantity()\">\r\n        <img src=\"../../assets/images/plus.png\"/>\r\n        <p>Add</p>\r\n      </div>\r\n    </ion-col>\r\n    <ion-col size=\"4\">\r\n      <div class=\"cart-icons\" (click)=\"remove_quantity()\">\r\n       <img src=\"../../assets/images/minus.png\"/>\r\n       <p>Reduce</p>\r\n      </div>\r\n    </ion-col>\r\n    <ion-col size=\"4\">\r\n      <div class=\"cart-icons\" (click)=\"remove()\">\r\n         <img src=\"../../assets/images/delete.png\"/>\r\n         <p>Eliminate</p>\r\n      </div>\r\n    </ion-col>\r\n  </ion-row>\r\n  <div class=\"footer-btn\">\r\n  <div class=\"price-button\">\r\n    <ion-row>\r\n      <ion-col size=\"6\" text-left>\r\n        <h3>Total </h3>\r\n      </ion-col>\r\n      <ion-col size=\"6\" text-right>\r\n        <h2><b>{{total | currency: 'USD'}}</b></h2>\r\n      </ion-col>\r\n    </ion-row>\r\n  \r\n  </div>\r\n\r\n  <ion-button lines=\"none\" class=\"cart-buttons\" expand=\"block\" fill=\"outline\" (click)=\"goTo()\">BUY</ion-button>\r\n</div> \r\n  </div>\r\n<div *ngIf=\"cartList.length==0\">\r\n<p text-center> No Product Found.</p>\r\n</div>\r\n \r\n</ion-content>\r\n"

/***/ }),

/***/ "./src/app/cartlist/cartlist-routing.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/cartlist/cartlist-routing.module.ts ***!
  \*****************************************************/
/*! exports provided: CartlistPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CartlistPageRoutingModule", function() { return CartlistPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _cartlist_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./cartlist.page */ "./src/app/cartlist/cartlist.page.ts");




const routes = [
    {
        path: '',
        component: _cartlist_page__WEBPACK_IMPORTED_MODULE_3__["CartlistPage"]
    }
];
let CartlistPageRoutingModule = class CartlistPageRoutingModule {
};
CartlistPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], CartlistPageRoutingModule);



/***/ }),

/***/ "./src/app/cartlist/cartlist.module.ts":
/*!*********************************************!*\
  !*** ./src/app/cartlist/cartlist.module.ts ***!
  \*********************************************/
/*! exports provided: CartlistPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CartlistPageModule", function() { return CartlistPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _cartlist_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./cartlist-routing.module */ "./src/app/cartlist/cartlist-routing.module.ts");
/* harmony import */ var _cartlist_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./cartlist.page */ "./src/app/cartlist/cartlist.page.ts");







let CartlistPageModule = class CartlistPageModule {
};
CartlistPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _cartlist_routing_module__WEBPACK_IMPORTED_MODULE_5__["CartlistPageRoutingModule"]
        ],
        declarations: [_cartlist_page__WEBPACK_IMPORTED_MODULE_6__["CartlistPage"]]
    })
], CartlistPageModule);



/***/ }),

/***/ "./src/app/cartlist/cartlist.page.scss":
/*!*********************************************!*\
  !*** ./src/app/cartlist/cartlist.page.scss ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-toolbar {\n  --background: #00b84c;\n}\n\nion-title {\n  color: #ffda01;\n  font-size: 20px;\n  vertical-align: middle;\n}\n\nion-icon {\n  color: #fff;\n  font-size: 24px;\n}\n\np.count {\n  text-align: center;\n  font-size: 14px;\n  vertical-align: middle;\n}\n\n.product-img {\n  width: 70px;\n  height: 70px;\n  border: 1px solid #bbb1b1;\n  border-radius: 50px;\n  padding: 8px;\n}\n\n.product-img img {\n  margin-right: 6px;\n  float: left;\n}\n\n.product-img h4 {\n  font-size: 16px;\n  vertical-align: middle;\n}\n\n.cart-list {\n  margin-bottom: 10px;\n}\n\n.cart-list ion-col {\n  border-right: 1px solid #d1d0d0;\n  padding: 10px;\n}\n\n.cart-list h5 {\n  font-size: 16px;\n  text-align: center;\n  vertical-align: middle;\n  font-weight: 600;\n  color: #595959;\n}\n\n.cart-icons {\n  margin: 20px 0px;\n}\n\n.cart-icons img {\n  width: 60px;\n}\n\n.cart-icons p {\n  font-size: 15px;\n  color: #00b84c;\n  margin: 0;\n}\n\n.price-button {\n  background: #f16000;\n  border-radius: 10px;\n  margin-bottom: 40px;\n  padding: 10px;\n}\n\n.price-button h3 {\n  color: #fff;\n  margin: 0;\n  font-size: 18px;\n  vertical-align: middle;\n}\n\n.price-button h2 {\n  color: #fff;\n  margin: 0;\n  font-size: 20px;\n  vertical-align: middle;\n}\n\n.cart-buttons {\n  color: #f16000;\n  --border-color: #f16000;\n  font-weight: bold;\n  font-size: 18px;\n  --border-radius: 5px;\n  height: 48px;\n  margin: 0px 30px;\n}\n\n.footer-btn {\n  padding: 20px 40px;\n}\n\n.carticons {\n  padding: 0px 60px;\n}\n\n.active {\n  border: 2px solid #ff2400;\n}\n\n@media (max-width: 320px) {\n  .product-img img {\n    width: 100%;\n  }\n\n  .carticons {\n    padding: 0px 36px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY2FydGxpc3QvRDpcXGJhYml0YVxcaG9ydG9zYWJvci9zcmNcXGFwcFxcY2FydGxpc3RcXGNhcnRsaXN0LnBhZ2Uuc2NzcyIsInNyYy9hcHAvY2FydGxpc3QvY2FydGxpc3QucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0kscUJBQUE7QUNDSjs7QURDQTtFQUNJLGNBQUE7RUFDQSxlQUFBO0VBQ0Esc0JBQUE7QUNFSjs7QURDQTtFQUNJLFdBQUE7RUFDQSxlQUFBO0FDRUo7O0FEQUE7RUFDSSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxzQkFBQTtBQ0dKOztBRERBO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSx5QkFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtBQ0lKOztBREZBO0VBQ0ksaUJBQUE7RUFFQSxXQUFBO0FDSUo7O0FERkE7RUFDSSxlQUFBO0VBQ0Esc0JBQUE7QUNLSjs7QURIQTtFQUNJLG1CQUFBO0FDTUo7O0FESkE7RUFDSSwrQkFBQTtFQUNBLGFBQUE7QUNPSjs7QURMQTtFQUNJLGVBQUE7RUFDQSxrQkFBQTtFQUNBLHNCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0FDUUo7O0FETkE7RUFDSSxnQkFBQTtBQ1NKOztBRFBBO0VBQ0ksV0FBQTtBQ1VKOztBRFJBO0VBQ0ksZUFBQTtFQUNBLGNBQUE7RUFDQSxTQUFBO0FDV0o7O0FEVEE7RUFDSSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSxhQUFBO0FDWUo7O0FEVkE7RUFDSSxXQUFBO0VBQ0EsU0FBQTtFQUNBLGVBQUE7RUFDQSxzQkFBQTtBQ2FKOztBRFhBO0VBQ0ksV0FBQTtFQUNBLFNBQUE7RUFDQSxlQUFBO0VBQ0Esc0JBQUE7QUNjSjs7QURaQTtFQUNJLGNBQUE7RUFDQSx1QkFBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLG9CQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FDZUo7O0FEYkE7RUFDSSxrQkFBQTtBQ2dCSjs7QURkQTtFQUNJLGlCQUFBO0FDaUJKOztBRGZBO0VBQ0kseUJBQUE7QUNrQko7O0FEaEJBO0VBQ0k7SUFDSSxXQUFBO0VDbUJOOztFRGpCRTtJQUNJLGlCQUFBO0VDb0JOO0FBQ0YiLCJmaWxlIjoic3JjL2FwcC9jYXJ0bGlzdC9jYXJ0bGlzdC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tdG9vbGJhciB7XHJcbiAgICAtLWJhY2tncm91bmQ6ICMwMGI4NGM7XHJcbn1cclxuaW9uLXRpdGxle1xyXG4gICAgY29sb3I6I2ZmZGEwMTtcclxuICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XHJcbn1cclxuXHJcbmlvbi1pY29uIHtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgZm9udC1zaXplOiAyNHB4O1xyXG59XHJcbnAuY291bnR7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xyXG59XHJcbi5wcm9kdWN0LWltZyB7XHJcbiAgICB3aWR0aDogNzBweDtcclxuICAgIGhlaWdodDogNzBweDtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICNiYmIxYjE7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1MHB4O1xyXG4gICAgcGFkZGluZzogOHB4O1xyXG59XHJcbi5wcm9kdWN0LWltZyBpbWd7XHJcbiAgICBtYXJnaW4tcmlnaHQ6NnB4O1xyXG4gICAgLy8gd2lkdGg6IDQwcHg7XHJcbiAgICBmbG9hdDogbGVmdDtcclxufVxyXG4ucHJvZHVjdC1pbWcgaDR7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xyXG59XHJcbi5jYXJ0LWxpc3R7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xyXG59XHJcbi5jYXJ0LWxpc3QgaW9uLWNvbCB7XHJcbiAgICBib3JkZXItcmlnaHQ6IDFweCBzb2xpZCAjZDFkMGQwO1xyXG4gICAgcGFkZGluZzogMTBweDtcclxufVxyXG4uY2FydC1saXN0IGg1e1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcclxuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICBjb2xvcjogIzU5NTk1OTtcclxufVxyXG4uY2FydC1pY29ucyB7XHJcbiAgICBtYXJnaW46IDIwcHggMHB4O1xyXG59XHJcbi5jYXJ0LWljb25zIGltZ3tcclxuICAgIHdpZHRoOiA2MHB4O1xyXG59XHJcbi5jYXJ0LWljb25zIHB7XHJcbiAgICBmb250LXNpemU6MTVweDtcclxuICAgIGNvbG9yOiMwMGI4NGM7XHJcbiAgICBtYXJnaW46IDA7XHJcbn1cclxuLnByaWNlLWJ1dHRvbntcclxuICAgIGJhY2tncm91bmQ6ICNmMTYwMDA7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogNDBweDsgXHJcbiAgICBwYWRkaW5nOiAxMHB4O1xyXG59XHJcbi5wcmljZS1idXR0b24gaDN7XHJcbiAgICBjb2xvcjogI2ZmZjtcclxuICAgIG1hcmdpbjowO1xyXG4gICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcclxufVxyXG4ucHJpY2UtYnV0dG9uIGgye1xyXG4gICAgY29sb3I6ICNmZmY7XHJcbiAgICBtYXJnaW46MDtcclxuICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XHJcbn1cclxuLmNhcnQtYnV0dG9uc3tcclxuICAgIGNvbG9yOiAjZjE2MDAwO1xyXG4gICAgLS1ib3JkZXItY29sb3I6ICNmMTYwMDA7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgIGZvbnQtc2l6ZTogMThweDtcclxuICAgIC0tYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gICAgaGVpZ2h0OjQ4cHg7XHJcbiAgICBtYXJnaW46IDBweCAzMHB4O1xyXG59XHJcbi5mb290ZXItYnRue1xyXG4gICAgcGFkZGluZzoyMHB4IDQwcHg7XHJcbn1cclxuLmNhcnRpY29uc3tcclxuICAgIHBhZGRpbmc6IDBweCA2MHB4O1xyXG59XHJcbi5hY3RpdmV7XHJcbiAgICBib3JkZXI6IDJweCBzb2xpZCAjZmYyNDAwO1xyXG59XHJcbkBtZWRpYSAobWF4LXdpZHRoOjMyMHB4KXtcclxuICAgIC5wcm9kdWN0LWltZyBpbWd7XHJcbiAgICAgICAgd2lkdGg6MTAwJTtcclxuICAgIH1cclxuICAgIC5jYXJ0aWNvbnMge1xyXG4gICAgICAgIHBhZGRpbmc6IDBweCAzNnB4O1xyXG4gICAgfVxyXG59IiwiaW9uLXRvb2xiYXIge1xuICAtLWJhY2tncm91bmQ6ICMwMGI4NGM7XG59XG5cbmlvbi10aXRsZSB7XG4gIGNvbG9yOiAjZmZkYTAxO1xuICBmb250LXNpemU6IDIwcHg7XG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG59XG5cbmlvbi1pY29uIHtcbiAgY29sb3I6ICNmZmY7XG4gIGZvbnQtc2l6ZTogMjRweDtcbn1cblxucC5jb3VudCB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgZm9udC1zaXplOiAxNHB4O1xuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xufVxuXG4ucHJvZHVjdC1pbWcge1xuICB3aWR0aDogNzBweDtcbiAgaGVpZ2h0OiA3MHB4O1xuICBib3JkZXI6IDFweCBzb2xpZCAjYmJiMWIxO1xuICBib3JkZXItcmFkaXVzOiA1MHB4O1xuICBwYWRkaW5nOiA4cHg7XG59XG5cbi5wcm9kdWN0LWltZyBpbWcge1xuICBtYXJnaW4tcmlnaHQ6IDZweDtcbiAgZmxvYXQ6IGxlZnQ7XG59XG5cbi5wcm9kdWN0LWltZyBoNCB7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbn1cblxuLmNhcnQtbGlzdCB7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG59XG5cbi5jYXJ0LWxpc3QgaW9uLWNvbCB7XG4gIGJvcmRlci1yaWdodDogMXB4IHNvbGlkICNkMWQwZDA7XG4gIHBhZGRpbmc6IDEwcHg7XG59XG5cbi5jYXJ0LWxpc3QgaDUge1xuICBmb250LXNpemU6IDE2cHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgY29sb3I6ICM1OTU5NTk7XG59XG5cbi5jYXJ0LWljb25zIHtcbiAgbWFyZ2luOiAyMHB4IDBweDtcbn1cblxuLmNhcnQtaWNvbnMgaW1nIHtcbiAgd2lkdGg6IDYwcHg7XG59XG5cbi5jYXJ0LWljb25zIHAge1xuICBmb250LXNpemU6IDE1cHg7XG4gIGNvbG9yOiAjMDBiODRjO1xuICBtYXJnaW46IDA7XG59XG5cbi5wcmljZS1idXR0b24ge1xuICBiYWNrZ3JvdW5kOiAjZjE2MDAwO1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICBtYXJnaW4tYm90dG9tOiA0MHB4O1xuICBwYWRkaW5nOiAxMHB4O1xufVxuXG4ucHJpY2UtYnV0dG9uIGgzIHtcbiAgY29sb3I6ICNmZmY7XG4gIG1hcmdpbjogMDtcbiAgZm9udC1zaXplOiAxOHB4O1xuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xufVxuXG4ucHJpY2UtYnV0dG9uIGgyIHtcbiAgY29sb3I6ICNmZmY7XG4gIG1hcmdpbjogMDtcbiAgZm9udC1zaXplOiAyMHB4O1xuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xufVxuXG4uY2FydC1idXR0b25zIHtcbiAgY29sb3I6ICNmMTYwMDA7XG4gIC0tYm9yZGVyLWNvbG9yOiAjZjE2MDAwO1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgZm9udC1zaXplOiAxOHB4O1xuICAtLWJvcmRlci1yYWRpdXM6IDVweDtcbiAgaGVpZ2h0OiA0OHB4O1xuICBtYXJnaW46IDBweCAzMHB4O1xufVxuXG4uZm9vdGVyLWJ0biB7XG4gIHBhZGRpbmc6IDIwcHggNDBweDtcbn1cblxuLmNhcnRpY29ucyB7XG4gIHBhZGRpbmc6IDBweCA2MHB4O1xufVxuXG4uYWN0aXZlIHtcbiAgYm9yZGVyOiAycHggc29saWQgI2ZmMjQwMDtcbn1cblxuQG1lZGlhIChtYXgtd2lkdGg6IDMyMHB4KSB7XG4gIC5wcm9kdWN0LWltZyBpbWcge1xuICAgIHdpZHRoOiAxMDAlO1xuICB9XG5cbiAgLmNhcnRpY29ucyB7XG4gICAgcGFkZGluZzogMHB4IDM2cHg7XG4gIH1cbn0iXX0= */"

/***/ }),

/***/ "./src/app/cartlist/cartlist.page.ts":
/*!*******************************************!*\
  !*** ./src/app/cartlist/cartlist.page.ts ***!
  \*******************************************/
/*! exports provided: CartlistPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CartlistPage", function() { return CartlistPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _cart_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../cart.service */ "./src/app/cart.service.ts");
/* harmony import */ var _api_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../api.service */ "./src/app/api.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");






let CartlistPage = class CartlistPage {
    constructor(cart, api, navCtrl, route, router) {
        this.cart = cart;
        this.api = api;
        this.navCtrl = navCtrl;
        this.route = route;
        this.router = router;
        this.cartList = [];
        this.total = 0;
        this.index = '';
        this.selectedData = {};
        this.navData = '';
        this.route.queryParams.subscribe(params => {
            if (params && params.value) {
                this.navData = JSON.parse(params.value);
            }
        });
        this.total = this.cart.calculateTotal();
        console.log(JSON.parse(localStorage.getItem('cart_data')));
        if (JSON.parse(localStorage.getItem('cart_data'))) {
            if (JSON.parse(localStorage.getItem('cart_data')).length > 0) {
                this.cartList = JSON.parse(localStorage.getItem('cart_data'));
                this.cartList.forEach(element => {
                    element.subtotal = parseInt(element.price) * element.quantity;
                    element.selectedstatus = false;
                });
            }
        }
        console.log(this.cartList, 'CARTLIST');
    }
    ngOnInit() {
    }
    goTo() {
        this.router.navigate(['/payment'], { queryParams: { value: JSON.stringify(this.navData) } });
        // this.navCtrl.navigateForward('/payment');
    }
    SelectedProduct(pro, index) {
        this.index = index;
        this.selectedData = pro;
        this.cartList.forEach(element => {
            if (element.id == this.selectedData.id) {
                this.selectedData.selectedstatus = true;
            }
            else {
                element.selectedstatus = false;
            }
        });
        console.log(this.selectedData);
    }
    add_quantity() {
        console.log(this.selectedData, "selected Product");
        if (Object.keys(this.selectedData).length) {
            this.selectedData.quantity = this.cart.addQuantity(this.selectedData.quantity);
            console.log(this.selectedData.quantity, "Qunatiyt", "++++++++++", this.cartList, "cartDAta");
            this.selectedData.subtotal = this.cart.updateTotal(this.selectedData).subtotal;
            localStorage.setItem("cart_data", JSON.stringify(this.cartList));
            this.total = this.cart.calculateTotal();
        }
        else {
            this.api.presentToast('Please first select a product to increase the quantity');
        }
    }
    remove_quantity() {
        console.log(this.selectedData, "selected Product");
        if (Object.keys(this.selectedData).length) {
            if (this.selectedData.quantity > 1) {
                this.selectedData.quantity = this.cart.removeQuantity(this.selectedData.quantity);
                console.log(this.selectedData.quantity, "Qunatiyt", "++++++++++", this.cartList, "cartDAta");
                this.selectedData.subtotal = this.cart.updateTotal(this.selectedData).subtotal;
                localStorage.setItem("cart_data", JSON.stringify(this.cartList));
                this.total = this.cart.calculateTotal();
            }
        }
        else {
            this.api.presentToast('Please first select a product to decrease the quantity');
        }
    }
    remove() {
        console.log(this.index);
        if (Object.keys(this.selectedData).length) {
            this.cartList.splice(this.index, 1);
            // var that = this;
            // this.cartList.forEach((element, key) => {
            //   console.log(key, 'index')
            //   console.log(element.id +'=='+ this.selectedData.id)
            //   if (element.id == this.selectedData.id) {          
            //     console.log("if", key)
            //     that.cartList.splice(1, key);
            //   } 
            // });
            console.log(this.cartList);
            localStorage.setItem("cart_data", JSON.stringify(this.cartList));
            this.total = this.cart.calculateTotal();
            // this.cartList = JSON.parse(localStorage.getItem('cart_data'));
        }
        else {
            this.api.presentToast('Please first select a product to remove from cart');
        }
    }
};
CartlistPage.ctorParameters = () => [
    { type: _cart_service__WEBPACK_IMPORTED_MODULE_2__["CartService"] },
    { type: _api_service__WEBPACK_IMPORTED_MODULE_3__["ApiService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] }
];
CartlistPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-cartlist',
        template: __webpack_require__(/*! raw-loader!./cartlist.page.html */ "./node_modules/raw-loader/index.js!./src/app/cartlist/cartlist.page.html"),
        styles: [__webpack_require__(/*! ./cartlist.page.scss */ "./src/app/cartlist/cartlist.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_cart_service__WEBPACK_IMPORTED_MODULE_2__["CartService"], _api_service__WEBPACK_IMPORTED_MODULE_3__["ApiService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"], _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"], _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"]])
], CartlistPage);



/***/ })

}]);
//# sourceMappingURL=cartlist-cartlist-module-es2015.js.map