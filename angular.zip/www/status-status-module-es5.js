(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["status-status-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/status/status.page.html":
/*!*******************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/status/status.page.html ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header class=\"header-top\">\r\n  <ion-toolbar>\r\n      <ion-buttons slot=\"start\">\r\n        <ion-menu-button></ion-menu-button>\r\n      </ion-buttons>\r\n    <ion-title text-left>Status</ion-title>\r\n    <ion-buttons slot=\"end\">\r\n      <!-- <ion-icon name=\"search\"></ion-icon>\r\n      <ion-icon name=\"md-more\"></ion-icon> -->\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <div class=\"order-number\">\r\n    <h2>{{ordersData[0]?.order_number}}</h2>\r\n  </div>\r\n  <div class=\"track-order\">\r\n    <img src=\"../../assets/images/marker.png\"/>\r\n    <ol class=\"track-progress\">\r\n      \r\n      <li class=\"done\">\r\n        <em>1</em>\r\n      </li>\r\n      <li class=\"todo\">\r\n        <em>2</em>\r\n      </li>\r\n      <li class=\"todo\">\r\n        <em>3</em>\r\n      </li>\r\n      <li class=\"todo\">\r\n        <em>4</em>\r\n      </li>\r\n    </ol>\r\n    <img src=\"../../assets/images/flag.png\" class=\"flag\"/>\r\n    <p text-center style=\"    color: #00b84c;\r\n    margin: 0px;\" *ngIf=\"ordersData.length>0\">{{ordersData[0]?.status}}</p>\r\n     <p text-center style=\"    color: #00b84c;\r\n     margin: 0px;\" *ngIf=\"ordersData.length==0\">{{status}}</p>\r\n  </div>\r\n  <!-- <ion-button expand=\"block\" class=\"ready-togobtn\">READY TO GO</ion-button> -->\r\n</ion-content>\r\n"

/***/ }),

/***/ "./src/app/status/status-routing.module.ts":
/*!*************************************************!*\
  !*** ./src/app/status/status-routing.module.ts ***!
  \*************************************************/
/*! exports provided: StatusPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StatusPageRoutingModule", function() { return StatusPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _status_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./status.page */ "./src/app/status/status.page.ts");




var routes = [
    {
        path: '',
        component: _status_page__WEBPACK_IMPORTED_MODULE_3__["StatusPage"]
    }
];
var StatusPageRoutingModule = /** @class */ (function () {
    function StatusPageRoutingModule() {
    }
    StatusPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], StatusPageRoutingModule);
    return StatusPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/status/status.module.ts":
/*!*****************************************!*\
  !*** ./src/app/status/status.module.ts ***!
  \*****************************************/
/*! exports provided: StatusPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StatusPageModule", function() { return StatusPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _status_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./status-routing.module */ "./src/app/status/status-routing.module.ts");
/* harmony import */ var _status_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./status.page */ "./src/app/status/status.page.ts");







var StatusPageModule = /** @class */ (function () {
    function StatusPageModule() {
    }
    StatusPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _status_routing_module__WEBPACK_IMPORTED_MODULE_5__["StatusPageRoutingModule"]
            ],
            declarations: [_status_page__WEBPACK_IMPORTED_MODULE_6__["StatusPage"]]
        })
    ], StatusPageModule);
    return StatusPageModule;
}());



/***/ }),

/***/ "./src/app/status/status.page.scss":
/*!*****************************************!*\
  !*** ./src/app/status/status.page.scss ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@charset \"UTF-8\";\nion-toolbar {\n  --background: #00b84c;\n}\nion-title {\n  color: #ffda01;\n  font-size: 20px;\n  vertical-align: middle;\n}\nion-icon {\n  color: #fff;\n  font-size: 24px;\n}\n.order-number h2 {\n  text-align: center;\n  padding-top: 70px;\n  font-size: 32px;\n  color: #666666;\n  font-weight: 600;\n}\n.ready-togobtn {\n  --background:#f16000;\n  color: #fff;\n  font-weight: bold;\n  font-size: 20px;\n  margin: 30px;\n  letter-spacing: 1px;\n  bottom: 20px;\n  position: absolute;\n  width: 86%;\n  height: 48px;\n}\n.track-progress {\n  margin: 0;\n  padding: 10px 10px 0 10px;\n  background: white;\n  height: 80px;\n  border-radius: 10px;\n}\n.track-progress li {\n  list-style-type: none;\n  display: inline-block;\n  position: relative;\n  font: 14px/14px Helvetica, sans-serif;\n  text-transform: uppercase;\n  text-align: center;\n  color: #bbb;\n  border-bottom: 2px #00b84c solid;\n  line-height: 3em;\n  width: 25%;\n  float: left;\n}\n.track-progress li:after {\n  content: \"  \";\n}\n.track-progress li:before {\n  position: relative;\n  bottom: -2.5em;\n  float: left;\n  left: 50%;\n  line-height: 1em;\n}\n@media (max-width: 800px) {\n  .track-progress li {\n    font-size: 0.7em;\n  }\n}\n.track-progress li span {\n  padding-left: 0.75em;\n}\n@media (max-width: 640px) {\n  .track-progress li span {\n    display: none;\n  }\n}\n.track-progress li.done {\n  color: #bbb;\n  font-weight: bold;\n  border-bottom: 4px #00b84c solid;\n}\n.track-progress em {\n  display: none;\n  font-weight: 700;\n  padding-left: 0.75em;\n}\n.track-order {\n  padding-top: 20%;\n  position: relative;\n}\n.track-order img {\n  width: 20px;\n  position: absolute;\n  left: 98px;\n  top: 48%;\n}\n.track-order .flag {\n  width: 20px;\n  right: 8px !important;\n  position: absolute !important;\n  left: auto;\n  top: 48%;\n}\n@media (max-width: 320px) {\n  .order-number h2 {\n    font-size: 24px;\n  }\n\n  .ready-togobtn {\n    font-size: 16px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc3RhdHVzL3N0YXR1cy5wYWdlLnNjc3MiLCJzcmMvYXBwL3N0YXR1cy9EOlxcYmFiaXRhXFxob3J0b3NhYm9yL3NyY1xcYXBwXFxzdGF0dXNcXHN0YXR1cy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsZ0JBQWdCO0FDQ2hCO0VBQ0kscUJBQUE7QURDSjtBQ0NBO0VBQ0ksY0FBQTtFQUNBLGVBQUE7RUFDQSxzQkFBQTtBREVKO0FDQ0E7RUFDSSxXQUFBO0VBQ0EsZUFBQTtBREVKO0FDQUE7RUFDSSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtBREdKO0FDREE7RUFDSSxvQkFBQTtFQUNBLFdBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxVQUFBO0VBQ0EsWUFBQTtBRElKO0FDSUE7RUFDSSxTQUFBO0VBQ0EseUJBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtBRERKO0FDR0k7RUFDRSxxQkFBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7RUFDQSxxQ0FqQk87RUFrQlAseUJBQUE7RUFDQSxrQkFBQTtFQUNBLFdBbEJPO0VBbUJQLGdDQUFBO0VBQ0EsZ0JBQUE7RUFDQSxVQUFBO0VBQ0EsV0FBQTtBREROO0FDR007RUFDRSxhQUFBO0FERFI7QUNJTTtFQUNFLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLFdBQUE7RUFDQSxTQUFBO0VBQ0EsZ0JBQUE7QURGUjtBQ0tNO0VBekJGO0lBMEJNLGdCQUFBO0VERlI7QUFDRjtBQ0lNO0VBQ0Usb0JBQUE7QURGUjtBQ0dRO0VBRkY7SUFHSSxhQUFBO0VEQVI7QUFDRjtBQ0lJO0VBQ0UsV0FqRE87RUFrRFAsaUJBQUE7RUFDQSxnQ0FBQTtBREZOO0FDd0JJO0VBQ0UsYUFBQTtFQUNBLGdCQUFBO0VBQ0Esb0JBQUE7QUR0Qk47QUN5QkU7RUFDSSxnQkFBQTtFQUNBLGtCQUFBO0FEdEJOO0FDd0JFO0VBQ0UsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFFBQUE7QURyQko7QUN1QkU7RUFDRSxXQUFBO0VBQ0EscUJBQUE7RUFDQSw2QkFBQTtFQUNBLFVBQUE7RUFDQSxRQUFBO0FEcEJKO0FDdUJFO0VBQ0U7SUFDRyxlQUFBO0VEcEJMOztFQ3NCRTtJQUNJLGVBQUE7RURuQk47QUFDRiIsImZpbGUiOiJzcmMvYXBwL3N0YXR1cy9zdGF0dXMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiQGNoYXJzZXQgXCJVVEYtOFwiO1xuaW9uLXRvb2xiYXIge1xuICAtLWJhY2tncm91bmQ6ICMwMGI4NGM7XG59XG5cbmlvbi10aXRsZSB7XG4gIGNvbG9yOiAjZmZkYTAxO1xuICBmb250LXNpemU6IDIwcHg7XG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG59XG5cbmlvbi1pY29uIHtcbiAgY29sb3I6ICNmZmY7XG4gIGZvbnQtc2l6ZTogMjRweDtcbn1cblxuLm9yZGVyLW51bWJlciBoMiB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgcGFkZGluZy10b3A6IDcwcHg7XG4gIGZvbnQtc2l6ZTogMzJweDtcbiAgY29sb3I6ICM2NjY2NjY7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG59XG5cbi5yZWFkeS10b2dvYnRuIHtcbiAgLS1iYWNrZ3JvdW5kOiNmMTYwMDA7XG4gIGNvbG9yOiAjZmZmO1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBtYXJnaW46IDMwcHg7XG4gIGxldHRlci1zcGFjaW5nOiAxcHg7XG4gIGJvdHRvbTogMjBweDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB3aWR0aDogODYlO1xuICBoZWlnaHQ6IDQ4cHg7XG59XG5cbi50cmFjay1wcm9ncmVzcyB7XG4gIG1hcmdpbjogMDtcbiAgcGFkZGluZzogMTBweCAxMHB4IDAgMTBweDtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG4gIGhlaWdodDogODBweDtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbn1cbi50cmFjay1wcm9ncmVzcyBsaSB7XG4gIGxpc3Qtc3R5bGUtdHlwZTogbm9uZTtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGZvbnQ6IDE0cHgvMTRweCBIZWx2ZXRpY2EsIHNhbnMtc2VyaWY7XG4gIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgY29sb3I6ICNiYmI7XG4gIGJvcmRlci1ib3R0b206IDJweCAjMDBiODRjIHNvbGlkO1xuICBsaW5lLWhlaWdodDogM2VtO1xuICB3aWR0aDogMjUlO1xuICBmbG9hdDogbGVmdDtcbn1cbi50cmFjay1wcm9ncmVzcyBsaTphZnRlciB7XG4gIGNvbnRlbnQ6IFwiwqDCoFwiO1xufVxuLnRyYWNrLXByb2dyZXNzIGxpOmJlZm9yZSB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgYm90dG9tOiAtMi41ZW07XG4gIGZsb2F0OiBsZWZ0O1xuICBsZWZ0OiA1MCU7XG4gIGxpbmUtaGVpZ2h0OiAxZW07XG59XG5AbWVkaWEgKG1heC13aWR0aDogODAwcHgpIHtcbiAgLnRyYWNrLXByb2dyZXNzIGxpIHtcbiAgICBmb250LXNpemU6IDAuN2VtO1xuICB9XG59XG4udHJhY2stcHJvZ3Jlc3MgbGkgc3BhbiB7XG4gIHBhZGRpbmctbGVmdDogMC43NWVtO1xufVxuQG1lZGlhIChtYXgtd2lkdGg6IDY0MHB4KSB7XG4gIC50cmFjay1wcm9ncmVzcyBsaSBzcGFuIHtcbiAgICBkaXNwbGF5OiBub25lO1xuICB9XG59XG4udHJhY2stcHJvZ3Jlc3MgbGkuZG9uZSB7XG4gIGNvbG9yOiAjYmJiO1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgYm9yZGVyLWJvdHRvbTogNHB4ICMwMGI4NGMgc29saWQ7XG59XG4udHJhY2stcHJvZ3Jlc3MgZW0ge1xuICBkaXNwbGF5OiBub25lO1xuICBmb250LXdlaWdodDogNzAwO1xuICBwYWRkaW5nLWxlZnQ6IDAuNzVlbTtcbn1cblxuLnRyYWNrLW9yZGVyIHtcbiAgcGFkZGluZy10b3A6IDIwJTtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuXG4udHJhY2stb3JkZXIgaW1nIHtcbiAgd2lkdGg6IDIwcHg7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbGVmdDogOThweDtcbiAgdG9wOiA0OCU7XG59XG5cbi50cmFjay1vcmRlciAuZmxhZyB7XG4gIHdpZHRoOiAyMHB4O1xuICByaWdodDogOHB4ICFpbXBvcnRhbnQ7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZSAhaW1wb3J0YW50O1xuICBsZWZ0OiBhdXRvO1xuICB0b3A6IDQ4JTtcbn1cblxuQG1lZGlhIChtYXgtd2lkdGg6IDMyMHB4KSB7XG4gIC5vcmRlci1udW1iZXIgaDIge1xuICAgIGZvbnQtc2l6ZTogMjRweDtcbiAgfVxuXG4gIC5yZWFkeS10b2dvYnRuIHtcbiAgICBmb250LXNpemU6IDE2cHg7XG4gIH1cbn0iLCJcclxuaW9uLXRvb2xiYXIge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjMDBiODRjO1xyXG59XHJcbmlvbi10aXRsZXtcclxuICAgIGNvbG9yOiNmZmRhMDE7XHJcbiAgICBmb250LXNpemU6IDIwcHg7XHJcbiAgICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xyXG59XHJcblxyXG5pb24taWNvbiB7XHJcbiAgICBjb2xvcjogI2ZmZjtcclxuICAgIGZvbnQtc2l6ZTogMjRweDtcclxufVxyXG4ub3JkZXItbnVtYmVyIGgye1xyXG4gICAgdGV4dC1hbGlnbjpjZW50ZXI7XHJcbiAgICBwYWRkaW5nLXRvcDo3MHB4O1xyXG4gICAgZm9udC1zaXplOiAzMnB4O1xyXG4gICAgY29sb3I6IzY2NjY2NjtcclxuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbn1cclxuLnJlYWR5LXRvZ29idG57XHJcbiAgICAtLWJhY2tncm91bmQ6I2YxNjAwMDtcclxuICAgIGNvbG9yOiNmZmY7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgIG1hcmdpbjogMzBweDtcclxuICAgIGxldHRlci1zcGFjaW5nOjFweDtcclxuICAgIGJvdHRvbTogMjBweDtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHdpZHRoOiA4NiU7XHJcbiAgICBoZWlnaHQ6NDhweDtcclxufVxyXG4kZm9udC1zdGFjazogMTRweC8xNHB4IEhlbHZldGljYSwgc2Fucy1zZXJpZjtcclxuJHByaW1hcnktY29sb3I6ICNGRjY2OTk7XHJcbiRiYXNlLWNvbG9yOiAjYmJiO1xyXG4kYnJlYWstbGFyZ2U6IDgwMHB4O1xyXG4kYnJlYWstbWVkaXVtOiA2NDBweDtcclxuJGJyZWFrLXNtYWxsOiA0ODBweDtcclxuLnRyYWNrLXByb2dyZXNzIHtcclxuICAgIG1hcmdpbjogMDtcclxuICAgIHBhZGRpbmc6IDEwcHggMTBweCAwIDEwcHg7XHJcbiAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcclxuICAgIGhlaWdodDogODBweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICBcclxuICAgIGxpIHtcclxuICAgICAgbGlzdC1zdHlsZS10eXBlOiBub25lO1xyXG4gICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgZm9udDogJGZvbnQtc3RhY2s7XHJcbiAgICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgY29sb3I6ICRiYXNlLWNvbG9yO1xyXG4gICAgICBib3JkZXItYm90dG9tOiAycHggICMwMGI4NGMgc29saWQ7XHJcbiAgICAgIGxpbmUtaGVpZ2h0OiAzZW07XHJcbiAgICAgIHdpZHRoOiAyNSU7XHJcbiAgICAgIGZsb2F0OiBsZWZ0O1xyXG4gICAgICBcclxuICAgICAgJjphZnRlciB7XHJcbiAgICAgICAgY29udGVudDogXCJcXDAwYTBcXDAwYTBcIjsgXHJcbiAgICAgIH1cclxuICAgICAgXHJcbiAgICAgICY6YmVmb3JlIHtcclxuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgYm90dG9tOiAtMi41ZW07XHJcbiAgICAgICAgZmxvYXQ6IGxlZnQ7XHJcbiAgICAgICAgbGVmdDogNTAlO1xyXG4gICAgICAgIGxpbmUtaGVpZ2h0OiAxZW07XHJcbiAgICAgIH1cclxuICAgICAgXHJcbiAgICAgIEBtZWRpYSAobWF4LXdpZHRoOiRicmVhay1sYXJnZSl7XHJcbiAgICAgICAgICBmb250LXNpemU6IDAuN2VtO1xyXG4gICAgICB9XHJcbiAgICAgIFxyXG4gICAgICBzcGFuIHtcclxuICAgICAgICBwYWRkaW5nLWxlZnQ6IDAuNzVlbTtcclxuICAgICAgICBAbWVkaWEgKG1heC13aWR0aDokYnJlYWstbWVkaXVtKXtcclxuICAgICAgICAgIGRpc3BsYXk6IG5vbmU7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBcclxuICAgIGxpLmRvbmUge1xyXG4gICAgICBjb2xvcjogJGJhc2UtY29sb3I7XHJcbiAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgICBib3JkZXItYm90dG9tOiA0cHggIzAwYjg0YyBzb2xpZDtcclxuICAgICAgXHJcbiAgICAgICY6YmVmb3JlIHtcclxuICAgICAgICAvLyBjb250ZW50OiBcIlwiO1xyXG4gICAgICAgIC8vIGJhY2tncm91bmQ6IzAwYjg0YztcclxuICAgICAgICAvLyBoZWlnaHQ6IDEuMmVtO1xyXG4gICAgICAgIC8vIHdpZHRoOiAxLjJlbTtcclxuICAgICAgICAvLyBsaW5lLWhlaWdodDogMS4yZW07XHJcbiAgICAgICAgLy8gYm9yZGVyOiBub25lO1xyXG4gICAgICAgIC8vIGJvcmRlci1yYWRpdXM6IDEuMmVtO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBcclxuICAgIGxpLnRvZG86YmVmb3JlIHtcclxuICAgIC8vICAgY29udGVudDogXCJcIjtcclxuICAgIC8vICAgYmFja2dyb3VuZDogd2hpdGU7XHJcbiAgICAvLyAgIGJvcmRlcjogMC4yNWVtIHNvbGlkICRiYXNlLWNvbG9yO1xyXG4gICAgLy8gICBoZWlnaHQ6IDAuOGVtO1xyXG4gICAgLy8gICB3aWR0aDogMC44ZW07XHJcbiAgICAvLyAgIGJvcmRlci1yYWRpdXM6IDAuOGVtO1xyXG4gICAgfVxyXG4gICAgXHJcbiAgICBlbSB7XHJcbiAgICAgIGRpc3BsYXk6IG5vbmU7XHJcbiAgICAgIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgICAgIHBhZGRpbmctbGVmdDogMC43NWVtO1xyXG4gICAgfVxyXG4gIH1cclxuICAudHJhY2stb3JkZXIge1xyXG4gICAgICBwYWRkaW5nLXRvcDoyMCU7XHJcbiAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICB9XHJcbiAgLnRyYWNrLW9yZGVyIGltZ3tcclxuICAgIHdpZHRoOiAyMHB4O1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgbGVmdDogOThweDtcclxuICAgIHRvcDogNDglO1xyXG4gIH1cclxuICAudHJhY2stb3JkZXIgLmZsYWd7XHJcbiAgICB3aWR0aDogMjBweDtcclxuICAgIHJpZ2h0OiA4cHggIWltcG9ydGFudDtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZSAhaW1wb3J0YW50O1xyXG4gICAgbGVmdDogYXV0bztcclxuICAgIHRvcDogNDglO1xyXG4gIH1cclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6MzIwcHgpe1xyXG4gICAgLm9yZGVyLW51bWJlciBoMntcclxuICAgICAgIGZvbnQtc2l6ZTogMjRweDtcclxuICAgIH1cclxuICAgIC5yZWFkeS10b2dvYnRuIHtcclxuICAgICAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICB9XHJcbiAgfSJdfQ== */"

/***/ }),

/***/ "./src/app/status/status.page.ts":
/*!***************************************!*\
  !*** ./src/app/status/status.page.ts ***!
  \***************************************/
/*! exports provided: StatusPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StatusPage", function() { return StatusPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../api.service */ "./src/app/api.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");




var StatusPage = /** @class */ (function () {
    function StatusPage(api, alertController, events) {
        var _this = this;
        this.api = api;
        this.alertController = alertController;
        this.events = events;
        this.ordersData = '';
        this.status = '';
        this.events.subscribe('status:created', function (time) {
            _this.presentAlertPrompt();
        });
    }
    StatusPage.prototype.ionViewDidEnter = function () {
        this.presentAlertPrompt();
    };
    StatusPage.prototype.ngOnInit = function () {
        // this.presentAlertPrompt();
    };
    StatusPage.prototype.order = function (data) {
        var _this = this;
        var url = '/order';
        this.api.post(url, data).subscribe(function (data) {
            console.log('res:- ', data.orders);
            if (data.orders == 'Result Not Found') {
                _this.status = "No Order Found";
            }
            else {
                _this.ordersData = data.orders;
            }
        }, function (err) {
            console.log('err:- ', err);
        });
    };
    StatusPage.prototype.presentAlertPrompt = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertController.create({
                            header: 'Enter',
                            inputs: [
                                {
                                    name: 'verify_no',
                                    type: 'text',
                                    placeholder: 'verification number'
                                }
                            ],
                            buttons: [
                                {
                                    text: 'Cancel',
                                    role: 'cancel',
                                    cssClass: 'secondary',
                                    handler: function () {
                                        console.log('Confirm Cancel');
                                    }
                                }, {
                                    text: 'Ok',
                                    handler: function (data) {
                                        console.log('Confirm Ok', data);
                                        if (data.verify_no == '') {
                                            _this.api.presentToast('Enter verification number.');
                                            return false;
                                        }
                                        else {
                                            _this.order(data);
                                        }
                                    }
                                }
                            ]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    StatusPage.ctorParameters = function () { return [
        { type: _api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Events"] }
    ]; };
    StatusPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-status',
            template: __webpack_require__(/*! raw-loader!./status.page.html */ "./node_modules/raw-loader/index.js!./src/app/status/status.page.html"),
            styles: [__webpack_require__(/*! ./status.page.scss */ "./src/app/status/status.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Events"]])
    ], StatusPage);
    return StatusPage;
}());



/***/ })

}]);
//# sourceMappingURL=status-status-module-es5.js.map