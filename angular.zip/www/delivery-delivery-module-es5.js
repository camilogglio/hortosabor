(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["delivery-delivery-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/delivery/delivery.page.html":
/*!***********************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/delivery/delivery.page.html ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header class=\"header-top\">\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <ion-title text-left>Delivery</ion-title>\r\n    <ion-buttons slot=\"end\">\r\n      <!-- <ion-icon name=\"search\"></ion-icon>\r\n      <ion-icon name=\"md-more\"></ion-icon> -->\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <div class=\"map\">\r\n    <!-- <img src=\"../../assets/images/marker.png\" class=\"map-marker\" />\r\n    <img src=\"../../assets/images/map.jpg\" /> -->\r\n    <div #map id=\"map\"></div>\r\n  </div>\r\n  <div class=\"form\">\r\n    <ion-item lines=\"none\">\r\n      <ion-label>Delivery Place</ion-label>\r\n      <ion-select mode=\"md\" okText=\"Okay\" cancelText=\"Dismiss\" [(ngModel)]=\"selectedPlace\" (ionChange)=\"changeDeliveryPlace($event)\">\r\n        <ion-select-option *ngFor=\"let place of places;\" value=\"{{place.id}}\">{{place.name}}</ion-select-option>\r\n        <!-- <ion-select-option value=\"blonde\">Blonde</ion-select-option>\r\n        <ion-select-option value=\"black\">Black</ion-select-option>\r\n        <ion-select-option value=\"red\">Red</ion-select-option> -->\r\n      </ion-select>\r\n    </ion-item>\r\n    <ion-item lines=\"none\">\r\n      <ion-label>Delivery Hour</ion-label>\r\n      <ion-select mode=\"md\" okText=\"Okay\" cancelText=\"Dismiss\" [(ngModel)]=\"selectedDate\">\r\n        <ion-select-option *ngFor=\"let date of intervalDate;\" value=\"{{date}}\">{{date}}</ion-select-option>\r\n        <!-- <ion-select-option value=\"blonde\">Blonde</ion-select-option>\r\n        <ion-select-option value=\"black\">Black</ion-select-option>\r\n        <ion-select-option value=\"red\">Red</ion-select-option> -->\r\n      </ion-select>\r\n    </ion-item>\r\n    <ion-item lines=\"none\">\r\n      <ion-textarea placeholder=\"Comments\" [(ngModel)]=\"comments\"></ion-textarea>\r\n    </ion-item>\r\n    <ion-button lines=\"none\" class=\"cart-buttons\" expand=\"block\" (click)=\"confirm()\">CONFIRM</ion-button>\r\n  </div>\r\n</ion-content>\r\n"

/***/ }),

/***/ "./src/app/delivery/delivery-routing.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/delivery/delivery-routing.module.ts ***!
  \*****************************************************/
/*! exports provided: DeliveryPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DeliveryPageRoutingModule", function() { return DeliveryPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _delivery_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./delivery.page */ "./src/app/delivery/delivery.page.ts");




var routes = [
    {
        path: '',
        component: _delivery_page__WEBPACK_IMPORTED_MODULE_3__["DeliveryPage"]
    }
];
var DeliveryPageRoutingModule = /** @class */ (function () {
    function DeliveryPageRoutingModule() {
    }
    DeliveryPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], DeliveryPageRoutingModule);
    return DeliveryPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/delivery/delivery.module.ts":
/*!*********************************************!*\
  !*** ./src/app/delivery/delivery.module.ts ***!
  \*********************************************/
/*! exports provided: DeliveryPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DeliveryPageModule", function() { return DeliveryPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _delivery_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./delivery-routing.module */ "./src/app/delivery/delivery-routing.module.ts");
/* harmony import */ var _delivery_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./delivery.page */ "./src/app/delivery/delivery.page.ts");







var DeliveryPageModule = /** @class */ (function () {
    function DeliveryPageModule() {
    }
    DeliveryPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _delivery_routing_module__WEBPACK_IMPORTED_MODULE_5__["DeliveryPageRoutingModule"]
            ],
            declarations: [_delivery_page__WEBPACK_IMPORTED_MODULE_6__["DeliveryPage"]]
        })
    ], DeliveryPageModule);
    return DeliveryPageModule;
}());



/***/ }),

/***/ "./src/app/delivery/delivery.page.scss":
/*!*********************************************!*\
  !*** ./src/app/delivery/delivery.page.scss ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-toolbar {\n  --background: #00b84c;\n}\n\nion-title {\n  color: #ffda01;\n  font-size: 20px;\n  vertical-align: middle;\n}\n\nion-icon {\n  color: #fff;\n  font-size: 24px;\n}\n\n.form {\n  padding: 20px;\n}\n\nion-item {\n  border: 1px solid #a7a6a6;\n  border-radius: 8px;\n  margin-bottom: 10px;\n}\n\n.sc-ion-textarea-md-h {\n  margin-top: 0px;\n  --placeholder-color: #222222;\n  --placeholder-opacity: 0.8;\n}\n\n.map-marker {\n  position: absolute;\n  z-index: 99;\n  width: 30px;\n  left: 50%;\n  top: 30%;\n}\n\n.map {\n  position: relative;\n  padding: 20px 20px 0px;\n}\n\n.cart-buttons {\n  color: #fff;\n  border-color: #f16000;\n  font-weight: bold;\n  font-size: 18px;\n  border-radius: 8px;\n  height: 48px;\n  letter-spacing: 1px;\n  background-color: #f16000;\n  --background: #f16000;\n  background: #f16000;\n}\n\n.cart-buttons.activated {\n  color: #fff;\n  border-color: #f16000;\n  font-weight: bold;\n  font-size: 18px;\n  border-radius: 8px;\n  height: 48px;\n  background-color: #f16000;\n  --background: #f16000;\n  background: #f16000;\n}\n\n#map_canvas {\n  width: 90%;\n  height: 80%;\n  border: 1px solid red;\n}\n\n#address {\n  padding: 10px;\n  font-size: 18px;\n  font-weight: bold;\n}\n\n#map {\n  width: 100%;\n  height: 50vh;\n}\n\n.map-wrapper {\n  position: relative;\n}\n\n.map-wrapper #map_center {\n  position: absolute;\n  z-index: 99;\n  height: 40px;\n  width: 40px;\n  top: 50%;\n  left: 50%;\n  margin-left: -21px;\n  margin-top: -41px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZGVsaXZlcnkvRDpcXGJhYml0YVxcaG9ydG9zYWJvci9zcmNcXGFwcFxcZGVsaXZlcnlcXGRlbGl2ZXJ5LnBhZ2Uuc2NzcyIsInNyYy9hcHAvZGVsaXZlcnkvZGVsaXZlcnkucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0kscUJBQUE7QUNDSjs7QURDRTtFQUNFLGNBQUE7RUFDQSxlQUFBO0VBQ0Esc0JBQUE7QUNFSjs7QURDRTtFQUNFLFdBQUE7RUFDQSxlQUFBO0FDRUo7O0FEQUU7RUFDRSxhQUFBO0FDR0o7O0FEREU7RUFDRSx5QkFBQTtFQUNBLGtCQUFBO0VBRUEsbUJBQUE7QUNHSjs7QURERTtFQUNFLGVBQUE7RUFDQSw0QkFBQTtFQUNBLDBCQUFBO0FDSUo7O0FERkU7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtFQUNBLFFBQUE7QUNLSjs7QURIRTtFQUNFLGtCQUFBO0VBQ0Esc0JBQUE7QUNNSjs7QURKRTtFQUNFLFdBQUE7RUFDQSxxQkFBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBRUEseUJBQUE7RUFDQSxxQkFBQTtFQUNBLG1CQUFBO0FDTUo7O0FESkU7RUFDRSxXQUFBO0VBQ0EscUJBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7RUFDQSx5QkFBQTtFQUNBLHFCQUFBO0VBQ0EsbUJBQUE7QUNPSjs7QURIQTtFQUNFLFVBQUE7RUFDQSxXQUFBO0VBQ0EscUJBQUE7QUNNRjs7QURGQTtFQUNFLGFBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7QUNLRjs7QURGQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0FDS0Y7O0FERkE7RUFDRSxrQkFBQTtBQ0tGOztBREhFO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxRQUFBO0VBQ0EsU0FBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7QUNLSiIsImZpbGUiOiJzcmMvYXBwL2RlbGl2ZXJ5L2RlbGl2ZXJ5LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi10b29sYmFyIHtcclxuICAgIC0tYmFja2dyb3VuZDogIzAwYjg0YztcclxuICB9XHJcbiAgaW9uLXRpdGxlIHtcclxuICAgIGNvbG9yOiAjZmZkYTAxO1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcclxuICB9XHJcbiAgXHJcbiAgaW9uLWljb24ge1xyXG4gICAgY29sb3I6ICNmZmY7XHJcbiAgICBmb250LXNpemU6IDI0cHg7XHJcbiAgfVxyXG4gIC5mb3JtIHtcclxuICAgIHBhZGRpbmc6IDIwcHg7XHJcbiAgfVxyXG4gIGlvbi1pdGVtIHtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICNhN2E2YTY7XHJcbiAgICBib3JkZXItcmFkaXVzOiA4cHg7XHJcbiAgICAvLyBwYWRkaW5nOiAzcHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xyXG4gIH1cclxuICAuc2MtaW9uLXRleHRhcmVhLW1kLWgge1xyXG4gICAgbWFyZ2luLXRvcDogMHB4O1xyXG4gICAgLS1wbGFjZWhvbGRlci1jb2xvcjogIzIyMjIyMjtcclxuICAgIC0tcGxhY2Vob2xkZXItb3BhY2l0eTogMC44O1xyXG4gIH1cclxuICAubWFwLW1hcmtlciB7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB6LWluZGV4OiA5OTtcclxuICAgIHdpZHRoOiAzMHB4O1xyXG4gICAgbGVmdDogNTAlO1xyXG4gICAgdG9wOiAzMCU7XHJcbiAgfVxyXG4gIC5tYXAge1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgcGFkZGluZzogMjBweCAyMHB4IDBweDtcclxuICB9XHJcbiAgLmNhcnQtYnV0dG9ucyB7XHJcbiAgICBjb2xvcjogI2ZmZjtcclxuICAgIGJvcmRlci1jb2xvcjogI2YxNjAwMDtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogOHB4O1xyXG4gICAgaGVpZ2h0OiA0OHB4O1xyXG4gICAgbGV0dGVyLXNwYWNpbmc6IDFweDtcclxuICAgIC8vIG1hcmdpbjogMHB4IDMwcHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjE2MDAwO1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjZjE2MDAwO1xyXG4gICAgYmFja2dyb3VuZDogI2YxNjAwMDtcclxuICB9XHJcbiAgLmNhcnQtYnV0dG9ucy5hY3RpdmF0ZWQge1xyXG4gICAgY29sb3I6ICNmZmY7XHJcbiAgICBib3JkZXItY29sb3I6ICNmMTYwMDA7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgIGZvbnQtc2l6ZTogMThweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDhweDtcclxuICAgIGhlaWdodDogNDhweDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNmMTYwMDA7XHJcbiAgICAtLWJhY2tncm91bmQ6ICNmMTYwMDA7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZjE2MDAwO1xyXG4gIH1cclxuICBcclxuXHJcbiNtYXBfY2FudmFzIHtcclxuICB3aWR0aDogOTAlO1xyXG4gIGhlaWdodDogODAlO1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkIHJlZDtcclxufVxyXG4gXHJcbiBcclxuI2FkZHJlc3Mge1xyXG4gIHBhZGRpbmc6IDEwcHg7XHJcbiAgZm9udC1zaXplOiAxOHB4O1xyXG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG59XHJcbiBcclxuI21hcCB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiA1MHZoO1xyXG59XHJcbiBcclxuLm1hcC13cmFwcGVyIHtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiBcclxuICAjbWFwX2NlbnRlciB7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB6LWluZGV4OiA5OTtcclxuICAgIGhlaWdodDogNDBweDtcclxuICAgIHdpZHRoOiA0MHB4O1xyXG4gICAgdG9wOiA1MCU7XHJcbiAgICBsZWZ0OiA1MCU7XHJcbiAgICBtYXJnaW4tbGVmdDogLTIxcHg7XHJcbiAgICBtYXJnaW4tdG9wOiAtNDFweDtcclxuICB9XHJcbn0iLCJpb24tdG9vbGJhciB7XG4gIC0tYmFja2dyb3VuZDogIzAwYjg0Yztcbn1cblxuaW9uLXRpdGxlIHtcbiAgY29sb3I6ICNmZmRhMDE7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbn1cblxuaW9uLWljb24ge1xuICBjb2xvcjogI2ZmZjtcbiAgZm9udC1zaXplOiAyNHB4O1xufVxuXG4uZm9ybSB7XG4gIHBhZGRpbmc6IDIwcHg7XG59XG5cbmlvbi1pdGVtIHtcbiAgYm9yZGVyOiAxcHggc29saWQgI2E3YTZhNjtcbiAgYm9yZGVyLXJhZGl1czogOHB4O1xuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xufVxuXG4uc2MtaW9uLXRleHRhcmVhLW1kLWgge1xuICBtYXJnaW4tdG9wOiAwcHg7XG4gIC0tcGxhY2Vob2xkZXItY29sb3I6ICMyMjIyMjI7XG4gIC0tcGxhY2Vob2xkZXItb3BhY2l0eTogMC44O1xufVxuXG4ubWFwLW1hcmtlciB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgei1pbmRleDogOTk7XG4gIHdpZHRoOiAzMHB4O1xuICBsZWZ0OiA1MCU7XG4gIHRvcDogMzAlO1xufVxuXG4ubWFwIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBwYWRkaW5nOiAyMHB4IDIwcHggMHB4O1xufVxuXG4uY2FydC1idXR0b25zIHtcbiAgY29sb3I6ICNmZmY7XG4gIGJvcmRlci1jb2xvcjogI2YxNjAwMDtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgYm9yZGVyLXJhZGl1czogOHB4O1xuICBoZWlnaHQ6IDQ4cHg7XG4gIGxldHRlci1zcGFjaW5nOiAxcHg7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmMTYwMDA7XG4gIC0tYmFja2dyb3VuZDogI2YxNjAwMDtcbiAgYmFja2dyb3VuZDogI2YxNjAwMDtcbn1cblxuLmNhcnQtYnV0dG9ucy5hY3RpdmF0ZWQge1xuICBjb2xvcjogI2ZmZjtcbiAgYm9yZGVyLWNvbG9yOiAjZjE2MDAwO1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgZm9udC1zaXplOiAxOHB4O1xuICBib3JkZXItcmFkaXVzOiA4cHg7XG4gIGhlaWdodDogNDhweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2YxNjAwMDtcbiAgLS1iYWNrZ3JvdW5kOiAjZjE2MDAwO1xuICBiYWNrZ3JvdW5kOiAjZjE2MDAwO1xufVxuXG4jbWFwX2NhbnZhcyB7XG4gIHdpZHRoOiA5MCU7XG4gIGhlaWdodDogODAlO1xuICBib3JkZXI6IDFweCBzb2xpZCByZWQ7XG59XG5cbiNhZGRyZXNzIHtcbiAgcGFkZGluZzogMTBweDtcbiAgZm9udC1zaXplOiAxOHB4O1xuICBmb250LXdlaWdodDogYm9sZDtcbn1cblxuI21hcCB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDUwdmg7XG59XG5cbi5tYXAtd3JhcHBlciB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cbi5tYXAtd3JhcHBlciAjbWFwX2NlbnRlciB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgei1pbmRleDogOTk7XG4gIGhlaWdodDogNDBweDtcbiAgd2lkdGg6IDQwcHg7XG4gIHRvcDogNTAlO1xuICBsZWZ0OiA1MCU7XG4gIG1hcmdpbi1sZWZ0OiAtMjFweDtcbiAgbWFyZ2luLXRvcDogLTQxcHg7XG59Il19 */"

/***/ }),

/***/ "./src/app/delivery/delivery.page.ts":
/*!*******************************************!*\
  !*** ./src/app/delivery/delivery.page.ts ***!
  \*******************************************/
/*! exports provided: DeliveryPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DeliveryPage", function() { return DeliveryPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
/* harmony import */ var _api_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../api.service */ "./src/app/api.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/geolocation/ngx */ "./node_modules/@ionic-native/geolocation/ngx/index.js");
/* harmony import */ var _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/native-geocoder/ngx */ "./node_modules/@ionic-native/native-geocoder/ngx/index.js");








var DeliveryPage = /** @class */ (function () {
    function DeliveryPage(navCtrl, storage, api, router, geolocation, nativeGeocoder) {
        this.navCtrl = navCtrl;
        this.storage = storage;
        this.api = api;
        this.router = router;
        this.geolocation = geolocation;
        this.nativeGeocoder = nativeGeocoder;
        this.places = [];
        this.selectedPlace = '';
        this.selectedPlaceDate = {};
        this.timeInterval = 0;
        this.intervalDate = [];
        this.selectedDate = '';
        this.comments = '';
        this.hours = ['10:00 AM', '11:00 AM', '12:00 PM', '01:00 PM', '02:00 PM', '03:00 PM', '04:00 PM', '05:00 PM', '06:00 PM', '07:00 PM'];
    }
    DeliveryPage.prototype.ngOnInit = function () {
        this.getDeliveryPlaces();
        this.loadMap();
    };
    DeliveryPage.prototype.loadMap = function (lat, lng) {
        var _this = this;
        if (lat && lng) {
            this.initMap(lat, lng);
        }
        else {
            this.geolocation.getCurrentPosition().then(function (resp) {
                _this.initMap(resp.coords.latitude, resp.coords.longitude);
            }).catch(function (error) {
                console.log('Error getting location', error);
            });
        }
    };
    DeliveryPage.prototype.initMap = function (lat, lng) {
        var latLng = new google.maps.LatLng(lat, lng);
        var mapOptions = {
            center: latLng,
            zoom: 15,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        // this.getAddressFromCoords(resp.coords.latitude, resp.coords.longitude);    // To get address from lat-long.
        this.map = new google.maps.Map(this.mapElement.nativeElement, mapOptions);
        var goldenGatePosition = { lat: this.map.center.lat(), lng: this.map.center.lng() };
        var marker = new google.maps.Marker({
            position: goldenGatePosition,
            map: this.map,
        });
    };
    /* getAddressFromCoords(lattitude, longitude) {
      console.log("getAddressFromCoords " + lattitude + " " + longitude);
      let options: NativeGeocoderOptions = {
        useLocale: true,
        maxResults: 5
      };
  
      var goldenGatePosition = {lat: lattitude,lng: longitude};
      var marker = new google.maps.Marker({
        position: goldenGatePosition,
        map: this.map,
      });
  
      this.nativeGeocoder.reverseGeocode(lattitude, longitude, options)
        .then((result: NativeGeocoderReverseResult[]) => {
          this.address = "";
          let responseAddress = [];
          for (let [key, value] of Object.entries(result[0])) {
            if (value.length > 0) {
              responseAddress.push(value);
            }
          }
          responseAddress.reverse();
          for (let value of responseAddress) {
            this.address += value + ", ";
          }
          this.address = this.address.slice(0, -2);
          console.log('Address:- ', this.address);
        })
        .catch((error: any) => {
          this.address = "Address Not Available!";
        });
    } */
    DeliveryPage.prototype.getDeliveryPlaces = function () {
        var _this = this;
        this.api.showLoader();
        var url = '/locations';
        var params = {};
        this.api.get(url, params).subscribe(function (data) {
            setTimeout(function () {
                _this.api.hideLoader();
            }, 100);
            console.log('Places res:- ', data);
            if (data.locations) {
                _this.places = data.locations;
            }
        }, function (err) {
            setTimeout(function () {
                _this.api.hideLoader();
            }, 100);
            console.log('Places err:- ', err);
        });
    };
    DeliveryPage.prototype.changeDeliveryPlace = function (evt) {
        var _this = this;
        this.selectedPlaceDate = {};
        console.log('selected delivery:- ', this.selectedPlace);
        var result = this.places.filter(function (x) { return x.id === _this.selectedPlace; }).map(function (x) { return x; });
        console.log('result:- ', result);
        if (result.length > 0) {
            this.selectedPlaceDate = result[0];
            this.selectedDate = '';
            this.loadMap(parseFloat(this.selectedPlaceDate.latitude), parseFloat(this.selectedPlaceDate.longitude));
            // this.getAddressFromCoords(parseFloat(this.selectedPlaceDate.latitude), parseFloat(this.selectedPlaceDate.longitude));
            this.changeDeleveryTime();
        }
    };
    DeliveryPage.prototype.changeDeleveryTime = function () {
        var _this = this;
        this.selectedPlaceDate;
        var hours = parseInt(this.selectedPlaceDate.hours);
        var days = hours / 24;
        var currentDate = new Date();
        this.timeInterval = currentDate.getDate() + days;
        this.intervalDate = [];
        var month = currentDate.getMonth() + 1;
        var year = currentDate.getFullYear();
        console.log('timeInt', this.timeInterval, this.timeInterval + '-' + month + '-' + year, new Date(this.timeInterval + '-' + month + '-' + year));
        var that = this;
        this.hours.forEach(function (element) {
            that.intervalDate.push(_this.timeInterval + '-' + ((month).toString().length > 1 ? month : '0' + month) + '-' + year + ' ' + element);
        });
        // this.intervalDate.push(this.timeInterval + '-' + ((month).toString().length > 1 ? month : '0'+month) + '-' + year);
        this.api.hideLoader();
        setTimeout(function () {
            _this.api.hideLoader();
        }, 500);
    };
    DeliveryPage.prototype.confirm = function () {
        var _this = this;
        setTimeout(function () {
            if (!_this.selectedPlace.length) {
                _this.api.presentToast('Please select delivery place.');
                return;
            }
            if (!_this.selectedDate.length) {
                _this.api.presentToast('Please select delivery hour.');
                return;
            }
            var params = {
                place: _this.selectedPlace,
                deliveryDate: _this.selectedDate,
            };
            if (_this.comments.length) {
                params.comment = _this.comments;
            }
            // this.navCtrl.navigateForward('/products', params);
            var navigationExtras = {
                queryParams: {
                    delivery: JSON.stringify(params)
                }
            };
            _this.router.navigate(['/products'], navigationExtras);
        }, 200);
    };
    DeliveryPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
        { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_3__["Storage"] },
        { type: _api_service__WEBPACK_IMPORTED_MODULE_4__["ApiService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
        { type: _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_6__["Geolocation"] },
        { type: _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_7__["NativeGeocoder"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('map', { static: false }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
    ], DeliveryPage.prototype, "mapElement", void 0);
    DeliveryPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-delivery',
            template: __webpack_require__(/*! raw-loader!./delivery.page.html */ "./node_modules/raw-loader/index.js!./src/app/delivery/delivery.page.html"),
            styles: [__webpack_require__(/*! ./delivery.page.scss */ "./src/app/delivery/delivery.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"],
            _ionic_storage__WEBPACK_IMPORTED_MODULE_3__["Storage"],
            _api_service__WEBPACK_IMPORTED_MODULE_4__["ApiService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"],
            _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_6__["Geolocation"],
            _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_7__["NativeGeocoder"]])
    ], DeliveryPage);
    return DeliveryPage;
}());



/***/ })

}]);
//# sourceMappingURL=delivery-delivery-module-es5.js.map