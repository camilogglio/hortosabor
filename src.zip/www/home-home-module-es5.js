(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/home/home.page.html":
/*!***************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/home/home.page.html ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content>\r\n  <div class=\"bg\">\r\n    <ion-header>\r\n      <ion-toolbar>\r\n        <ion-buttons slot=\"start\">\r\n          <!-- <ion-menu-button></ion-menu-button> -->\r\n        </ion-buttons>\r\n      </ion-toolbar>\r\n    </ion-header>\r\n    <div class=\"logo text-center\">\r\n      <img src=\"../../assets/images/Logo.png\" />\r\n      <p class=\"subtitle\">Lorem ipsum dolor sit</p>\r\n    </div>\r\n    <div class=\"bottom text-center\">\r\n      <div class=\"agree\">\r\n        <div class=\"form-group\">\r\n          <input type=\"checkbox\" id=\"agree\" [(ngModel)]=\"terms\" (change)=\"agreeTerms()\">\r\n          <label for=\"agree\">I agree to the terms & conditions.</label>\r\n        </div>\r\n      </div>\r\n      <ion-button expand=\"block\" (click)=\"enter()\">Enter</ion-button>\r\n    </div>\r\n  </div>\r\n\r\n  <!-- <form action=\"\" method=\"post\" id=\"pay\" name=\"pay\">\r\n    <fieldset>\r\n      <ul>\r\n        <li>\r\n          <label for=\"email\">Email</label>\r\n          <input id=\"email\" name=\"email\" value=\"test_user_19653727@testuser.com\" type=\"email\"\r\n            placeholder=\"your email\" />\r\n        </li>\r\n        <li>\r\n          <label for=\"cardNumber\">Credit card number:</label>\r\n          <input type=\"text\" id=\"cardNumber\" data-checkout=\"cardNumber\" placeholder=\"4509 9535 6623 3704\"\r\n            value=\"4509 9535 6623 3704\" />\r\n        </li>\r\n        <li>\r\n          <label for=\"securityCode\">Security code:</label>\r\n          <input type=\"text\" id=\"securityCode\" data-checkout=\"securityCode\" placeholder=\"123\" value=\"123\" />\r\n        </li>\r\n        <li>\r\n          <label for=\"cardExpirationMonth\">Expiration month:</label>\r\n          <input type=\"text\" id=\"cardExpirationMonth\" data-checkout=\"cardExpirationMonth\" placeholder=\"12\" value=\"12\" />\r\n        </li>\r\n        <li>\r\n          <label for=\"cardExpirationYear\">Expiration year:</label>\r\n          <input type=\"text\" id=\"cardExpirationYear\" data-checkout=\"cardExpirationYear\" placeholder=\"2015\"\r\n            value=\"2024\" />\r\n        </li>\r\n        <li>\r\n          <label for=\"cardholderName\">Card holder name:</label>\r\n          <input type=\"text\" id=\"cardholderName\" data-checkout=\"cardholderName\" placeholder=\"APRO\" value=\"APRO\" />\r\n        </li>\r\n        <li>\r\n          <label for=\"docType\">Document type:</label>\r\n          <select id=\"docType\" data-checkout=\"docType\"></select>\r\n        </li>\r\n        <li>\r\n          <label for=\"docNumber\">Document number:</label>\r\n          <input type=\"text\" id=\"docNumber\" data-checkout=\"docNumber\" placeholder=\"12345678\" value=\"12345678\" />\r\n        </li>\r\n      </ul>\r\n      <input type=\"submit\" value=\"Pay!\" (click)=\"pay()\" />\r\n    </fieldset>\r\n  </form> -->\r\n</ion-content>"

/***/ }),

/***/ "./src/app/home/home.module.ts":
/*!*************************************!*\
  !*** ./src/app/home/home.module.ts ***!
  \*************************************/
/*! exports provided: HomePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageModule", function() { return HomePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./home.page */ "./src/app/home/home.page.ts");







var HomePageModule = /** @class */ (function () {
    function HomePageModule() {
    }
    HomePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                    {
                        path: '',
                        component: _home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]
                    }
                ])
            ],
            declarations: [_home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]]
        })
    ], HomePageModule);
    return HomePageModule;
}());



/***/ }),

/***/ "./src/app/home/home.page.scss":
/*!*************************************!*\
  !*** ./src/app/home/home.page.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".bg {\n  background: url('bg.jpg');\n  height: 100%;\n  width: 100%;\n  background-size: cover;\n  background-position: bottom;\n  background-repeat: no-repeat;\n}\n\nion-toolbar {\n  --border-width: 0 0 0.55px;\n  background: transparent;\n  --background: transparent;\n  border-bottom: 0px;\n  --border: 0px;\n  --border-color: transparent;\n}\n\n.logo {\n  padding-top: 44%;\n}\n\n.subtitle {\n  margin-top: 0px;\n  color: #ffda01;\n  font-size: 30px;\n  text-align: center;\n  padding: 0px 20px;\n}\n\n.bottom {\n  position: absolute;\n  bottom: 50px;\n  padding: 40px;\n  text-align: center;\n  margin: 0 auto;\n  width: 100%;\n}\n\n.form-group {\n  display: block;\n  margin-bottom: 15px;\n}\n\n.form-group input {\n  padding: 0;\n  height: initial;\n  width: initial;\n  margin-bottom: 0;\n  display: none;\n  cursor: pointer;\n}\n\n.form-group label {\n  position: relative;\n  cursor: pointer;\n  color: #fff;\n  font-size: 18px;\n  letter-spacing: 1px;\n}\n\n.form-group label:before {\n  content: \"\";\n  -webkit-appearance: none;\n  background-color: transparent;\n  border: 2px solid #ffffff;\n  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05), inset 0px -15px 10px -12px rgba(0, 0, 0, 0.05);\n  padding: 10px;\n  display: inline-block;\n  position: relative;\n  vertical-align: middle;\n  cursor: pointer;\n  margin-right: 5px;\n}\n\n.form-group input:checked + label:after {\n  content: \"\";\n  display: block;\n  position: absolute;\n  top: 2px;\n  left: 9px;\n  width: 6px;\n  height: 14px;\n  border: solid #ffffff;\n  border-width: 0 2px 2px 0;\n  -webkit-transform: rotate(45deg);\n          transform: rotate(45deg);\n}\n\nion-button {\n  --background: #fff;\n  color: #676564;\n  text-transform: uppercase;\n  font-weight: bold;\n  font-size: 20px;\n  height: 48px;\n}\n\n.agree {\n  border-bottom: 1px solid #eee;\n  line-height: 20px;\n  margin-bottom: 35px;\n}\n\nion-button.activated {\n  --color-activated: #676564;\n  --color-focused: #676564;\n}\n\n@media (max-width: 360px) {\n  .form-group label {\n    font-size: 14px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS9EOlxcYmFiaXRhXFxob3J0b3NhYm9yL3NyY1xcYXBwXFxob21lXFxob21lLnBhZ2Uuc2NzcyIsInNyYy9hcHAvaG9tZS9ob21lLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxzQkFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7QUNDRjs7QURDQTtFQUNFLDBCQUFBO0VBQ0EsdUJBQUE7RUFDQSx5QkFBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLDJCQUFBO0FDRUY7O0FEQ0E7RUFFRSxnQkFBQTtBQ0NGOztBRElBO0VBQ0UsZUFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtBQ0RGOztBREdBO0VBQ0Usa0JBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLFdBQUE7QUNBRjs7QURFQTtFQUNFLGNBQUE7RUFDQSxtQkFBQTtBQ0NGOztBREVBO0VBQ0UsVUFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSxhQUFBO0VBQ0EsZUFBQTtBQ0NGOztBREVBO0VBQ0Usa0JBQUE7RUFDRSxlQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxtQkFBQTtBQ0NKOztBREVBO0VBQ0UsV0FBQTtFQUNBLHdCQUFBO0VBQ0EsNkJBQUE7RUFDQSx5QkFBQTtFQUNBLHlGQUFBO0VBQ0EsYUFBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7RUFDQSxzQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtBQ0NGOztBREVBO0VBQ0UsV0FBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7RUFDQSxxQkFBQTtFQUNBLHlCQUFBO0VBQ0EsZ0NBQUE7VUFBQSx3QkFBQTtBQ0NGOztBRENBO0VBQ0Usa0JBQUE7RUFDQSxjQUFBO0VBQ0EseUJBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0FDRUY7O0FEQUE7RUFDRSw2QkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7QUNHRjs7QUREQTtFQUNFLDBCQUFBO0VBQ0Esd0JBQUE7QUNJRjs7QURGQTtFQUNFO0lBQ0UsZUFBQTtFQ0tGO0FBQ0YiLCJmaWxlIjoic3JjL2FwcC9ob21lL2hvbWUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmJnIHtcclxuICBiYWNrZ3JvdW5kOiB1cmwoLi4vLi4vYXNzZXRzL2ltYWdlcy9iZy5qcGcpO1xyXG4gIGhlaWdodDogMTAwJTtcclxuICB3aWR0aDogMTAwJTtcclxuICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xyXG4gIGJhY2tncm91bmQtcG9zaXRpb246IGJvdHRvbTtcclxuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG59XHJcbmlvbi10b29sYmFyIHtcclxuICAtLWJvcmRlci13aWR0aDogMCAwIDAuNTVweDtcclxuICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gIGJvcmRlci1ib3R0b206IDBweDtcclxuICAtLWJvcmRlcjogMHB4O1xyXG4gIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcclxufVxyXG5cclxuLmxvZ297XHJcbiAgLy8gcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHBhZGRpbmctdG9wOiA0NCU7XHJcbiAgLy8gbGVmdDogNTAlO1xyXG4gIC8vIG1hcmdpbi1yaWdodDogLTUwJTtcclxuICAvLyB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNTAlKTtcclxufVxyXG4uc3VidGl0bGV7XHJcbiAgbWFyZ2luLXRvcDogMHB4O1xyXG4gIGNvbG9yOiAjZmZkYTAxO1xyXG4gIGZvbnQtc2l6ZTogMzBweDtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgcGFkZGluZzogMHB4IDIwcHg7XHJcbn1cclxuLmJvdHRvbSB7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIGJvdHRvbTogNTBweDtcclxuICBwYWRkaW5nOiA0MHB4O1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBtYXJnaW46IDAgYXV0bztcclxuICB3aWR0aDogMTAwJTtcclxufVxyXG4uZm9ybS1ncm91cCB7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTVweDtcclxufVxyXG5cclxuLmZvcm0tZ3JvdXAgaW5wdXQge1xyXG4gIHBhZGRpbmc6IDA7XHJcbiAgaGVpZ2h0OiBpbml0aWFsO1xyXG4gIHdpZHRoOiBpbml0aWFsO1xyXG4gIG1hcmdpbi1ib3R0b206IDA7XHJcbiAgZGlzcGxheTogbm9uZTtcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuXHJcbi5mb3JtLWdyb3VwIGxhYmVsIHtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICBjb2xvcjogI2ZmZjtcclxuICAgIGZvbnQtc2l6ZTogMThweDtcclxuICAgIGxldHRlci1zcGFjaW5nOiAxcHg7XHJcbn1cclxuXHJcbi5mb3JtLWdyb3VwIGxhYmVsOmJlZm9yZSB7XHJcbiAgY29udGVudDonJztcclxuICAtd2Via2l0LWFwcGVhcmFuY2U6IG5vbmU7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcbiAgYm9yZGVyOiAycHggc29saWQgI2ZmZmZmZjtcclxuICBib3gtc2hhZG93OiAwIDFweCAycHggcmdiYSgwLCAwLCAwLCAwLjA1KSwgaW5zZXQgMHB4IC0xNXB4IDEwcHggLTEycHggcmdiYSgwLCAwLCAwLCAwLjA1KTtcclxuICBwYWRkaW5nOiAxMHB4O1xyXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgbWFyZ2luLXJpZ2h0OiA1cHg7XHJcbn1cclxuXHJcbi5mb3JtLWdyb3VwIGlucHV0OmNoZWNrZWQgKyBsYWJlbDphZnRlciB7XHJcbiAgY29udGVudDogJyc7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHRvcDogMnB4O1xyXG4gIGxlZnQ6IDlweDtcclxuICB3aWR0aDogNnB4O1xyXG4gIGhlaWdodDogMTRweDtcclxuICBib3JkZXI6IHNvbGlkICNmZmZmZmY7XHJcbiAgYm9yZGVyLXdpZHRoOiAwIDJweCAycHggMDtcclxuICB0cmFuc2Zvcm06IHJvdGF0ZSg0NWRlZyk7XHJcbn1cclxuaW9uLWJ1dHRvbiB7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjZmZmO1xyXG4gIGNvbG9yOiAjNjc2NTY0O1xyXG4gIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgZm9udC1zaXplOiAyMHB4O1xyXG4gIGhlaWdodDogNDhweDtcclxufVxyXG4uYWdyZWUge1xyXG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZWVlO1xyXG4gIGxpbmUtaGVpZ2h0OiAyMHB4O1xyXG4gIG1hcmdpbi1ib3R0b206IDM1cHg7XHJcbn1cclxuaW9uLWJ1dHRvbi5hY3RpdmF0ZWQge1xyXG4gIC0tY29sb3ItYWN0aXZhdGVkOiAjNjc2NTY0O1xyXG4gIC0tY29sb3ItZm9jdXNlZDogIzY3NjU2NDtcclxufVxyXG5AbWVkaWEgKG1heC13aWR0aDozNjBweCl7XHJcbiAgLmZvcm0tZ3JvdXAgbGFiZWwge1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG59XHJcbn0iLCIuYmcge1xuICBiYWNrZ3JvdW5kOiB1cmwoLi4vLi4vYXNzZXRzL2ltYWdlcy9iZy5qcGcpO1xuICBoZWlnaHQ6IDEwMCU7XG4gIHdpZHRoOiAxMDAlO1xuICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xuICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBib3R0b207XG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG59XG5cbmlvbi10b29sYmFyIHtcbiAgLS1ib3JkZXItd2lkdGg6IDAgMCAwLjU1cHg7XG4gIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICBib3JkZXItYm90dG9tOiAwcHg7XG4gIC0tYm9yZGVyOiAwcHg7XG4gIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbn1cblxuLmxvZ28ge1xuICBwYWRkaW5nLXRvcDogNDQlO1xufVxuXG4uc3VidGl0bGUge1xuICBtYXJnaW4tdG9wOiAwcHg7XG4gIGNvbG9yOiAjZmZkYTAxO1xuICBmb250LXNpemU6IDMwcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgcGFkZGluZzogMHB4IDIwcHg7XG59XG5cbi5ib3R0b20ge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGJvdHRvbTogNTBweDtcbiAgcGFkZGluZzogNDBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBtYXJnaW46IDAgYXV0bztcbiAgd2lkdGg6IDEwMCU7XG59XG5cbi5mb3JtLWdyb3VwIHtcbiAgZGlzcGxheTogYmxvY2s7XG4gIG1hcmdpbi1ib3R0b206IDE1cHg7XG59XG5cbi5mb3JtLWdyb3VwIGlucHV0IHtcbiAgcGFkZGluZzogMDtcbiAgaGVpZ2h0OiBpbml0aWFsO1xuICB3aWR0aDogaW5pdGlhbDtcbiAgbWFyZ2luLWJvdHRvbTogMDtcbiAgZGlzcGxheTogbm9uZTtcbiAgY3Vyc29yOiBwb2ludGVyO1xufVxuXG4uZm9ybS1ncm91cCBsYWJlbCB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICBjb2xvcjogI2ZmZjtcbiAgZm9udC1zaXplOiAxOHB4O1xuICBsZXR0ZXItc3BhY2luZzogMXB4O1xufVxuXG4uZm9ybS1ncm91cCBsYWJlbDpiZWZvcmUge1xuICBjb250ZW50OiBcIlwiO1xuICAtd2Via2l0LWFwcGVhcmFuY2U6IG5vbmU7XG4gIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xuICBib3JkZXI6IDJweCBzb2xpZCAjZmZmZmZmO1xuICBib3gtc2hhZG93OiAwIDFweCAycHggcmdiYSgwLCAwLCAwLCAwLjA1KSwgaW5zZXQgMHB4IC0xNXB4IDEwcHggLTEycHggcmdiYSgwLCAwLCAwLCAwLjA1KTtcbiAgcGFkZGluZzogMTBweDtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gIGN1cnNvcjogcG9pbnRlcjtcbiAgbWFyZ2luLXJpZ2h0OiA1cHg7XG59XG5cbi5mb3JtLWdyb3VwIGlucHV0OmNoZWNrZWQgKyBsYWJlbDphZnRlciB7XG4gIGNvbnRlbnQ6IFwiXCI7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMnB4O1xuICBsZWZ0OiA5cHg7XG4gIHdpZHRoOiA2cHg7XG4gIGhlaWdodDogMTRweDtcbiAgYm9yZGVyOiBzb2xpZCAjZmZmZmZmO1xuICBib3JkZXItd2lkdGg6IDAgMnB4IDJweCAwO1xuICB0cmFuc2Zvcm06IHJvdGF0ZSg0NWRlZyk7XG59XG5cbmlvbi1idXR0b24ge1xuICAtLWJhY2tncm91bmQ6ICNmZmY7XG4gIGNvbG9yOiAjNjc2NTY0O1xuICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBoZWlnaHQ6IDQ4cHg7XG59XG5cbi5hZ3JlZSB7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZWVlO1xuICBsaW5lLWhlaWdodDogMjBweDtcbiAgbWFyZ2luLWJvdHRvbTogMzVweDtcbn1cblxuaW9uLWJ1dHRvbi5hY3RpdmF0ZWQge1xuICAtLWNvbG9yLWFjdGl2YXRlZDogIzY3NjU2NDtcbiAgLS1jb2xvci1mb2N1c2VkOiAjNjc2NTY0O1xufVxuXG5AbWVkaWEgKG1heC13aWR0aDogMzYwcHgpIHtcbiAgLmZvcm0tZ3JvdXAgbGFiZWwge1xuICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgfVxufSJdfQ== */"

/***/ }),

/***/ "./src/app/home/home.page.ts":
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/*! exports provided: HomePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePage", function() { return HomePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _api_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../api.service */ "./src/app/api.service.ts");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");





var HomePage = /** @class */ (function () {
    function HomePage(navCtrl, api, storage, menu) {
        var _this = this;
        this.navCtrl = navCtrl;
        this.api = api;
        this.storage = storage;
        this.menu = menu;
        this.terms = false;
        this.doSubmit = false;
        this.menu.swipeEnable(false);
        // console.log(Mercadopago);
        Mercadopago.setPublishableKey("TEST-aece564d-442e-4a41-80b9-a07f31624d11");
        // Mercadopago.createToken(form, (tokenHandler) => {
        //   console.log('tokenHandler', tokenHandler);
        // });
        // Mercadopago.getIdentificationTypes();
        // this.addEvent(document.querySelector('input[data-checkout="cardNumber"]'), 'keyup', this.guessingPaymentMethod);
        // this.addEvent(document.querySelector('input[data-checkout="cardNumber"]'), 'change', this.guessingPaymentMethod);
        this.storage.get('terms').then(function (val) {
            if (val) {
                _this.terms = val;
                setTimeout(function () {
                    if (_this.terms) {
                        _this.storage.set('terms', _this.terms);
                        _this.navCtrl.navigateRoot('/delivery');
                    }
                    else {
                        // this.api.presentToast('Please accept terms & conditions.');
                    }
                }, 3000);
            }
            else {
            }
        });
    }
    HomePage.prototype.pay = function () {
        this.addEvent(document.querySelector('#pay'), 'submit', this.doPay);
    };
    HomePage.prototype.enter = function () {
        if (this.terms) {
            this.storage.set('terms', this.terms);
            this.navCtrl.navigateRoot('/delivery');
        }
        else {
            this.api.presentToast('Please accept terms & conditions.');
        }
    };
    HomePage.prototype.agreeTerms = function () {
        console.log('Terms', this.terms);
    };
    HomePage.prototype.getBin = function () {
        var ccNumber = document.querySelector('input[data-checkout="cardNumber"]');
        return ccNumber['value'].replace(/[ .-]/g, '').slice(0, 6);
    };
    ;
    HomePage.prototype.doPay = function (event) {
        // event.preventDefault();
        if (!this.doSubmit) {
            console.log('event', event);
            var $form = document.querySelector('#pay');
            console.log($form);
            // Mercadopago.createToken($form, this.sdkResponseHandler); // The function "sdkResponseHandler" is defined below
            Mercadopago.createToken($form, function (res) {
                console.log('token', res);
            }); // The function "sdkResponseHandler" is defined below
            return false;
        }
    };
    ;
    HomePage.prototype.guessingPaymentMethod = function (event) {
        var bin = this.getBin();
        if (event.type == "keyup") {
            if (bin.length >= 6) {
                Mercadopago.getPaymentMethod({
                    "bin": bin
                }, this.setPaymentMethodInfo);
            }
        }
        else {
            setTimeout(function () {
                if (bin.length >= 6) {
                    Mercadopago.getPaymentMethod({
                        "bin": bin
                    }, this.setPaymentMethodInfo());
                }
            }, 100);
        }
    };
    ;
    // Mercadopago.getIdentificationTypes();
    HomePage.prototype.setPaymentMethodInfo = function (status, response) {
        if (status == 200) {
            // do somethings ex: show logo of the payment method
            var form = document.querySelector('#pay');
            if (document.querySelector("input[name=paymentMethodId]") == null) {
                var paymentMethod = document.createElement('input');
                paymentMethod.setAttribute('name', "paymentMethodId");
                paymentMethod.setAttribute('type', "hidden");
                paymentMethod.setAttribute('value', response[0].id);
                form.appendChild(paymentMethod);
            }
            else {
                document.querySelector("input[name=paymentMethodId]")['value'] = response[0].id;
            }
        }
    };
    ;
    HomePage.prototype.addEvent = function (el, eventName, handler) {
        console.log('el', el);
        if (el) {
            if (el.addEventListener) {
                el.addEventListener(eventName, handler);
            }
            else {
                el.attachEvent('on' + eventName, function () {
                    handler.call(el);
                });
            }
        }
    };
    ;
    HomePage.prototype.sdkResponseHandler = function (status, response) {
        console.log(response);
        if (status != 200 && status != 201) {
            alert("verify filled data");
        }
        else {
            var form = document.querySelector('#pay');
            var card = document.createElement('input');
            card.setAttribute('name', "token");
            card.setAttribute('type', "hidden");
            card.setAttribute('value', response.id);
            form.appendChild(card);
            // doSubmit=true;
            // form.submit();
        }
    };
    ;
    HomePage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
        { type: _api_service__WEBPACK_IMPORTED_MODULE_3__["ApiService"] },
        { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_4__["Storage"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["MenuController"] }
    ]; };
    HomePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-home',
            template: __webpack_require__(/*! raw-loader!./home.page.html */ "./node_modules/raw-loader/index.js!./src/app/home/home.page.html"),
            styles: [__webpack_require__(/*! ./home.page.scss */ "./src/app/home/home.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"],
            _api_service__WEBPACK_IMPORTED_MODULE_3__["ApiService"],
            _ionic_storage__WEBPACK_IMPORTED_MODULE_4__["Storage"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["MenuController"]])
    ], HomePage);
    return HomePage;
}());



/***/ })

}]);
//# sourceMappingURL=home-home-module-es5.js.map