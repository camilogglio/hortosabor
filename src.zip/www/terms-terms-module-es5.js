(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["terms-terms-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/terms/terms.page.html":
/*!*****************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/terms/terms.page.html ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header class=\"header-top\">\n  <ion-toolbar>\n      <ion-buttons slot=\"start\">\n        <ion-menu-button></ion-menu-button>\n      </ion-buttons>\n    <ion-title text-left>Terms & Conditions</ion-title>\n    <ion-buttons slot=\"end\">\n      <!-- <ion-icon name=\"search\"></ion-icon>\n      <ion-icon name=\"md-more\"></ion-icon> -->\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n  <div class=\"order-number\">\n    What is Lorem Ipsum?\n    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\n    \n    Why do we use it?\n    It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n    \n    \n    Where does it come from?\n    Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \"de Finibus Bonorum et Malorum\" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.\n    \n    The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from \"de Finibus Bonorum et Malorum\" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.\n  </div>\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/terms/terms-routing.module.ts":
/*!***********************************************!*\
  !*** ./src/app/terms/terms-routing.module.ts ***!
  \***********************************************/
/*! exports provided: TermsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TermsPageRoutingModule", function() { return TermsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _terms_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./terms.page */ "./src/app/terms/terms.page.ts");




var routes = [
    {
        path: '',
        component: _terms_page__WEBPACK_IMPORTED_MODULE_3__["TermsPage"]
    }
];
var TermsPageRoutingModule = /** @class */ (function () {
    function TermsPageRoutingModule() {
    }
    TermsPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], TermsPageRoutingModule);
    return TermsPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/terms/terms.module.ts":
/*!***************************************!*\
  !*** ./src/app/terms/terms.module.ts ***!
  \***************************************/
/*! exports provided: TermsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TermsPageModule", function() { return TermsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _terms_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./terms-routing.module */ "./src/app/terms/terms-routing.module.ts");
/* harmony import */ var _terms_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./terms.page */ "./src/app/terms/terms.page.ts");







var TermsPageModule = /** @class */ (function () {
    function TermsPageModule() {
    }
    TermsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _terms_routing_module__WEBPACK_IMPORTED_MODULE_5__["TermsPageRoutingModule"]
            ],
            declarations: [_terms_page__WEBPACK_IMPORTED_MODULE_6__["TermsPage"]]
        })
    ], TermsPageModule);
    return TermsPageModule;
}());



/***/ }),

/***/ "./src/app/terms/terms.page.scss":
/*!***************************************!*\
  !*** ./src/app/terms/terms.page.scss ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@charset \"UTF-8\";\nion-toolbar {\n  --background: #00b84c;\n}\nion-title {\n  color: #ffda01;\n  font-size: 20px;\n  vertical-align: middle;\n}\nion-icon {\n  color: #fff;\n  font-size: 24px;\n}\n.order-number h2 {\n  text-align: center;\n  padding-top: 70px;\n  font-size: 32px;\n  color: #666666;\n  font-weight: 600;\n}\n.ready-togobtn {\n  --background:#f16000;\n  color: #fff;\n  font-weight: bold;\n  font-size: 20px;\n  margin: 30px;\n  letter-spacing: 1px;\n  bottom: 20px;\n  position: absolute;\n  width: 86%;\n  height: 48px;\n}\n.track-progress {\n  margin: 0;\n  padding: 10px 10px 0 10px;\n  background: white;\n  height: 80px;\n  border-radius: 10px;\n}\n.track-progress li {\n  list-style-type: none;\n  display: inline-block;\n  position: relative;\n  font: 14px/14px Helvetica, sans-serif;\n  text-transform: uppercase;\n  text-align: center;\n  color: #bbb;\n  border-bottom: 2px #00b84c solid;\n  line-height: 3em;\n  width: 25%;\n  float: left;\n}\n.track-progress li:after {\n  content: \"  \";\n}\n.track-progress li:before {\n  position: relative;\n  bottom: -2.5em;\n  float: left;\n  left: 50%;\n  line-height: 1em;\n}\n@media (max-width: 800px) {\n  .track-progress li {\n    font-size: 0.7em;\n  }\n}\n.track-progress li span {\n  padding-left: 0.75em;\n}\n@media (max-width: 640px) {\n  .track-progress li span {\n    display: none;\n  }\n}\n.track-progress li.done {\n  color: #bbb;\n  font-weight: bold;\n  border-bottom: 4px #00b84c solid;\n}\n.track-progress em {\n  display: none;\n  font-weight: 700;\n  padding-left: 0.75em;\n}\n.track-order {\n  padding-top: 20%;\n  position: relative;\n}\n.track-order img {\n  width: 20px;\n  position: absolute;\n  left: 98px;\n  top: 48%;\n}\n.track-order .flag {\n  width: 20px;\n  right: 8px !important;\n  position: absolute !important;\n  left: auto;\n  top: 48%;\n}\n@media (max-width: 320px) {\n  .order-number h2 {\n    font-size: 24px;\n  }\n\n  .ready-togobtn {\n    font-size: 16px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdGVybXMvdGVybXMucGFnZS5zY3NzIiwic3JjL2FwcC90ZXJtcy9EOlxcYmFiaXRhXFxob3J0b3NhYm9yL3NyY1xcYXBwXFx0ZXJtc1xcdGVybXMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLGdCQUFnQjtBQ0NoQjtFQUNJLHFCQUFBO0FEQ0o7QUNDQTtFQUNJLGNBQUE7RUFDQSxlQUFBO0VBQ0Esc0JBQUE7QURFSjtBQ0NBO0VBQ0ksV0FBQTtFQUNBLGVBQUE7QURFSjtBQ0FBO0VBQ0ksa0JBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7QURHSjtBQ0RBO0VBQ0ksb0JBQUE7RUFDQSxXQUFBO0VBQ0EsaUJBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7QURJSjtBQ0lBO0VBQ0ksU0FBQTtFQUNBLHlCQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7QURESjtBQ0dJO0VBQ0UscUJBQUE7RUFDQSxxQkFBQTtFQUNBLGtCQUFBO0VBQ0EscUNBakJPO0VBa0JQLHlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQWxCTztFQW1CUCxnQ0FBQTtFQUNBLGdCQUFBO0VBQ0EsVUFBQTtFQUNBLFdBQUE7QURETjtBQ0dNO0VBQ0UsYUFBQTtBRERSO0FDSU07RUFDRSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtFQUNBLGdCQUFBO0FERlI7QUNLTTtFQXpCRjtJQTBCTSxnQkFBQTtFREZSO0FBQ0Y7QUNJTTtFQUNFLG9CQUFBO0FERlI7QUNHUTtFQUZGO0lBR0ksYUFBQTtFREFSO0FBQ0Y7QUNJSTtFQUNFLFdBakRPO0VBa0RQLGlCQUFBO0VBQ0EsZ0NBQUE7QURGTjtBQ3dCSTtFQUNFLGFBQUE7RUFDQSxnQkFBQTtFQUNBLG9CQUFBO0FEdEJOO0FDeUJFO0VBQ0ksZ0JBQUE7RUFDQSxrQkFBQTtBRHRCTjtBQ3dCRTtFQUNFLFdBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxRQUFBO0FEckJKO0FDdUJFO0VBQ0UsV0FBQTtFQUNBLHFCQUFBO0VBQ0EsNkJBQUE7RUFDQSxVQUFBO0VBQ0EsUUFBQTtBRHBCSjtBQ3VCRTtFQUNFO0lBQ0csZUFBQTtFRHBCTDs7RUNzQkU7SUFDSSxlQUFBO0VEbkJOO0FBQ0YiLCJmaWxlIjoic3JjL2FwcC90ZXJtcy90ZXJtcy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJAY2hhcnNldCBcIlVURi04XCI7XG5pb24tdG9vbGJhciB7XG4gIC0tYmFja2dyb3VuZDogIzAwYjg0Yztcbn1cblxuaW9uLXRpdGxlIHtcbiAgY29sb3I6ICNmZmRhMDE7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbn1cblxuaW9uLWljb24ge1xuICBjb2xvcjogI2ZmZjtcbiAgZm9udC1zaXplOiAyNHB4O1xufVxuXG4ub3JkZXItbnVtYmVyIGgyIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBwYWRkaW5nLXRvcDogNzBweDtcbiAgZm9udC1zaXplOiAzMnB4O1xuICBjb2xvcjogIzY2NjY2NjtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbn1cblxuLnJlYWR5LXRvZ29idG4ge1xuICAtLWJhY2tncm91bmQ6I2YxNjAwMDtcbiAgY29sb3I6ICNmZmY7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBmb250LXNpemU6IDIwcHg7XG4gIG1hcmdpbjogMzBweDtcbiAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbiAgYm90dG9tOiAyMHB4O1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHdpZHRoOiA4NiU7XG4gIGhlaWdodDogNDhweDtcbn1cblxuLnRyYWNrLXByb2dyZXNzIHtcbiAgbWFyZ2luOiAwO1xuICBwYWRkaW5nOiAxMHB4IDEwcHggMCAxMHB4O1xuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgaGVpZ2h0OiA4MHB4O1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xufVxuLnRyYWNrLXByb2dyZXNzIGxpIHtcbiAgbGlzdC1zdHlsZS10eXBlOiBub25lO1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgZm9udDogMTRweC8xNHB4IEhlbHZldGljYSwgc2Fucy1zZXJpZjtcbiAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogI2JiYjtcbiAgYm9yZGVyLWJvdHRvbTogMnB4ICMwMGI4NGMgc29saWQ7XG4gIGxpbmUtaGVpZ2h0OiAzZW07XG4gIHdpZHRoOiAyNSU7XG4gIGZsb2F0OiBsZWZ0O1xufVxuLnRyYWNrLXByb2dyZXNzIGxpOmFmdGVyIHtcbiAgY29udGVudDogXCLCoMKgXCI7XG59XG4udHJhY2stcHJvZ3Jlc3MgbGk6YmVmb3JlIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBib3R0b206IC0yLjVlbTtcbiAgZmxvYXQ6IGxlZnQ7XG4gIGxlZnQ6IDUwJTtcbiAgbGluZS1oZWlnaHQ6IDFlbTtcbn1cbkBtZWRpYSAobWF4LXdpZHRoOiA4MDBweCkge1xuICAudHJhY2stcHJvZ3Jlc3MgbGkge1xuICAgIGZvbnQtc2l6ZTogMC43ZW07XG4gIH1cbn1cbi50cmFjay1wcm9ncmVzcyBsaSBzcGFuIHtcbiAgcGFkZGluZy1sZWZ0OiAwLjc1ZW07XG59XG5AbWVkaWEgKG1heC13aWR0aDogNjQwcHgpIHtcbiAgLnRyYWNrLXByb2dyZXNzIGxpIHNwYW4ge1xuICAgIGRpc3BsYXk6IG5vbmU7XG4gIH1cbn1cbi50cmFjay1wcm9ncmVzcyBsaS5kb25lIHtcbiAgY29sb3I6ICNiYmI7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBib3JkZXItYm90dG9tOiA0cHggIzAwYjg0YyBzb2xpZDtcbn1cbi50cmFjay1wcm9ncmVzcyBlbSB7XG4gIGRpc3BsYXk6IG5vbmU7XG4gIGZvbnQtd2VpZ2h0OiA3MDA7XG4gIHBhZGRpbmctbGVmdDogMC43NWVtO1xufVxuXG4udHJhY2stb3JkZXIge1xuICBwYWRkaW5nLXRvcDogMjAlO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG5cbi50cmFjay1vcmRlciBpbWcge1xuICB3aWR0aDogMjBweDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBsZWZ0OiA5OHB4O1xuICB0b3A6IDQ4JTtcbn1cblxuLnRyYWNrLW9yZGVyIC5mbGFnIHtcbiAgd2lkdGg6IDIwcHg7XG4gIHJpZ2h0OiA4cHggIWltcG9ydGFudDtcbiAgcG9zaXRpb246IGFic29sdXRlICFpbXBvcnRhbnQ7XG4gIGxlZnQ6IGF1dG87XG4gIHRvcDogNDglO1xufVxuXG5AbWVkaWEgKG1heC13aWR0aDogMzIwcHgpIHtcbiAgLm9yZGVyLW51bWJlciBoMiB7XG4gICAgZm9udC1zaXplOiAyNHB4O1xuICB9XG5cbiAgLnJlYWR5LXRvZ29idG4ge1xuICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgfVxufSIsIlxyXG5pb24tdG9vbGJhciB7XHJcbiAgICAtLWJhY2tncm91bmQ6ICMwMGI4NGM7XHJcbn1cclxuaW9uLXRpdGxle1xyXG4gICAgY29sb3I6I2ZmZGEwMTtcclxuICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XHJcbn1cclxuXHJcbmlvbi1pY29uIHtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgZm9udC1zaXplOiAyNHB4O1xyXG59XHJcbi5vcmRlci1udW1iZXIgaDJ7XHJcbiAgICB0ZXh0LWFsaWduOmNlbnRlcjtcclxuICAgIHBhZGRpbmctdG9wOjcwcHg7XHJcbiAgICBmb250LXNpemU6IDMycHg7XHJcbiAgICBjb2xvcjojNjY2NjY2O1xyXG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcclxufVxyXG4ucmVhZHktdG9nb2J0bntcclxuICAgIC0tYmFja2dyb3VuZDojZjE2MDAwO1xyXG4gICAgY29sb3I6I2ZmZjtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgbWFyZ2luOiAzMHB4O1xyXG4gICAgbGV0dGVyLXNwYWNpbmc6MXB4O1xyXG4gICAgYm90dG9tOiAyMHB4O1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgd2lkdGg6IDg2JTtcclxuICAgIGhlaWdodDo0OHB4O1xyXG59XHJcbiRmb250LXN0YWNrOiAxNHB4LzE0cHggSGVsdmV0aWNhLCBzYW5zLXNlcmlmO1xyXG4kcHJpbWFyeS1jb2xvcjogI0ZGNjY5OTtcclxuJGJhc2UtY29sb3I6ICNiYmI7XHJcbiRicmVhay1sYXJnZTogODAwcHg7XHJcbiRicmVhay1tZWRpdW06IDY0MHB4O1xyXG4kYnJlYWstc21hbGw6IDQ4MHB4O1xyXG4udHJhY2stcHJvZ3Jlc3Mge1xyXG4gICAgbWFyZ2luOiAwO1xyXG4gICAgcGFkZGluZzogMTBweCAxMHB4IDAgMTBweDtcclxuICAgIGJhY2tncm91bmQ6IHdoaXRlO1xyXG4gICAgaGVpZ2h0OiA4MHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgIFxyXG4gICAgbGkge1xyXG4gICAgICBsaXN0LXN0eWxlLXR5cGU6IG5vbmU7XHJcbiAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICBmb250OiAkZm9udC1zdGFjaztcclxuICAgICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICBjb2xvcjogJGJhc2UtY29sb3I7XHJcbiAgICAgIGJvcmRlci1ib3R0b206IDJweCAgIzAwYjg0YyBzb2xpZDtcclxuICAgICAgbGluZS1oZWlnaHQ6IDNlbTtcclxuICAgICAgd2lkdGg6IDI1JTtcclxuICAgICAgZmxvYXQ6IGxlZnQ7XHJcbiAgICAgIFxyXG4gICAgICAmOmFmdGVyIHtcclxuICAgICAgICBjb250ZW50OiBcIlxcMDBhMFxcMDBhMFwiOyBcclxuICAgICAgfVxyXG4gICAgICBcclxuICAgICAgJjpiZWZvcmUge1xyXG4gICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgICBib3R0b206IC0yLjVlbTtcclxuICAgICAgICBmbG9hdDogbGVmdDtcclxuICAgICAgICBsZWZ0OiA1MCU7XHJcbiAgICAgICAgbGluZS1oZWlnaHQ6IDFlbTtcclxuICAgICAgfVxyXG4gICAgICBcclxuICAgICAgQG1lZGlhIChtYXgtd2lkdGg6JGJyZWFrLWxhcmdlKXtcclxuICAgICAgICAgIGZvbnQtc2l6ZTogMC43ZW07XHJcbiAgICAgIH1cclxuICAgICAgXHJcbiAgICAgIHNwYW4ge1xyXG4gICAgICAgIHBhZGRpbmctbGVmdDogMC43NWVtO1xyXG4gICAgICAgIEBtZWRpYSAobWF4LXdpZHRoOiRicmVhay1tZWRpdW0pe1xyXG4gICAgICAgICAgZGlzcGxheTogbm9uZTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIFxyXG4gICAgbGkuZG9uZSB7XHJcbiAgICAgIGNvbG9yOiAkYmFzZS1jb2xvcjtcclxuICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICAgIGJvcmRlci1ib3R0b206IDRweCAjMDBiODRjIHNvbGlkO1xyXG4gICAgICBcclxuICAgICAgJjpiZWZvcmUge1xyXG4gICAgICAgIC8vIGNvbnRlbnQ6IFwiXCI7XHJcbiAgICAgICAgLy8gYmFja2dyb3VuZDojMDBiODRjO1xyXG4gICAgICAgIC8vIGhlaWdodDogMS4yZW07XHJcbiAgICAgICAgLy8gd2lkdGg6IDEuMmVtO1xyXG4gICAgICAgIC8vIGxpbmUtaGVpZ2h0OiAxLjJlbTtcclxuICAgICAgICAvLyBib3JkZXI6IG5vbmU7XHJcbiAgICAgICAgLy8gYm9yZGVyLXJhZGl1czogMS4yZW07XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIFxyXG4gICAgbGkudG9kbzpiZWZvcmUge1xyXG4gICAgLy8gICBjb250ZW50OiBcIlwiO1xyXG4gICAgLy8gICBiYWNrZ3JvdW5kOiB3aGl0ZTtcclxuICAgIC8vICAgYm9yZGVyOiAwLjI1ZW0gc29saWQgJGJhc2UtY29sb3I7XHJcbiAgICAvLyAgIGhlaWdodDogMC44ZW07XHJcbiAgICAvLyAgIHdpZHRoOiAwLjhlbTtcclxuICAgIC8vICAgYm9yZGVyLXJhZGl1czogMC44ZW07XHJcbiAgICB9XHJcbiAgICBcclxuICAgIGVtIHtcclxuICAgICAgZGlzcGxheTogbm9uZTtcclxuICAgICAgZm9udC13ZWlnaHQ6IDcwMDtcclxuICAgICAgcGFkZGluZy1sZWZ0OiAwLjc1ZW07XHJcbiAgICB9XHJcbiAgfVxyXG4gIC50cmFjay1vcmRlciB7XHJcbiAgICAgIHBhZGRpbmctdG9wOjIwJTtcclxuICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIH1cclxuICAudHJhY2stb3JkZXIgaW1ne1xyXG4gICAgd2lkdGg6IDIwcHg7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBsZWZ0OiA5OHB4O1xyXG4gICAgdG9wOiA0OCU7XHJcbiAgfVxyXG4gIC50cmFjay1vcmRlciAuZmxhZ3tcclxuICAgIHdpZHRoOiAyMHB4O1xyXG4gICAgcmlnaHQ6IDhweCAhaW1wb3J0YW50O1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlICFpbXBvcnRhbnQ7XHJcbiAgICBsZWZ0OiBhdXRvO1xyXG4gICAgdG9wOiA0OCU7XHJcbiAgfVxyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDozMjBweCl7XHJcbiAgICAub3JkZXItbnVtYmVyIGgye1xyXG4gICAgICAgZm9udC1zaXplOiAyNHB4O1xyXG4gICAgfVxyXG4gICAgLnJlYWR5LXRvZ29idG4ge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgIH1cclxuICB9Il19 */"

/***/ }),

/***/ "./src/app/terms/terms.page.ts":
/*!*************************************!*\
  !*** ./src/app/terms/terms.page.ts ***!
  \*************************************/
/*! exports provided: TermsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TermsPage", function() { return TermsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var TermsPage = /** @class */ (function () {
    function TermsPage() {
    }
    TermsPage.prototype.ngOnInit = function () {
    };
    TermsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-terms',
            template: __webpack_require__(/*! raw-loader!./terms.page.html */ "./node_modules/raw-loader/index.js!./src/app/terms/terms.page.html"),
            styles: [__webpack_require__(/*! ./terms.page.scss */ "./src/app/terms/terms.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], TermsPage);
    return TermsPage;
}());



/***/ })

}]);
//# sourceMappingURL=terms-terms-module-es5.js.map