import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule, HttpHandler } from '@angular/common/http';
import { Http, HttpModule, RequestOptions, Headers } from '@angular/http';
import { AlertController, LoadingController } from '@ionic/angular';
import 'rxjs/add/operator/map';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  url = 'https://botz-web-api.herokuapp.com';
  constructor(
    public http: Http,
    public HttpC: HttpClient,
    public loadingController: LoadingController,
    public alertController: AlertController
  ) { }

  public post(url, params) {
    const headers = new Headers();
    headers.append('Accept', 'application/json');
    headers.append('Content-Type', 'application/json');
    const options = new RequestOptions({ headers: headers });
    return this.http
      .post(url, JSON.stringify(params), options)
      .map(res => res.json());
  }

  public get(url, params) {
    const headers = new Headers();
    headers.append('Accept', 'application/json');
    headers.append('Content-Type', 'application/json');
    const options = new RequestOptions({
      headers: headers,
      params: params
    });
    return this.http.get(url, options).map(res => res.json());
  }
}
