import { Component } from '@angular/core';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  terms: any = false;
  constructor(
    public navCtrl: NavController
  ) {}
  enter() {
    if(this.terms) {
      
    }
    this.navCtrl.navigateRoot('/products');
  }

  agreeTerms() {
    console.log('Terms', this.terms);
  }

}
